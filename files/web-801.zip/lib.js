/* Calculations: prayer times (Umm al-Qura), Hijri date, helpers. ES5 for Android 6 WebView. */
(function (w) {
  var D2R = Math.PI / 180, R2D = 180 / Math.PI;
  function sin(d) { return Math.sin(d * D2R); }
  function cos(d) { return Math.cos(d * D2R); }
  function tan(d) { return Math.tan(d * D2R); }
  function asin(x) { return Math.asin(x) * R2D; }
  function acos(x) { return Math.acos(x) * R2D; }
  function atan2(y, x) { return Math.atan2(y, x) * R2D; }
  function acot(x) { return Math.atan(1 / x) * R2D; }
  function fixAngle(a) { a = a - 360 * Math.floor(a / 360); return a; }
  function fixHour(a) { a = a - 24 * Math.floor(a / 24); return a; }

  function julian(y, m, d) {
    if (m <= 2) { y -= 1; m += 12; }
    var A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
  }
  function sunPosition(jd) {
    var D = jd - 2451545.0;
    var g = fixAngle(357.529 + 0.98560028 * D);
    var q = fixAngle(280.459 + 0.98564736 * D);
    var L = fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
    var e = 23.439 - 0.00000036 * D;
    var RA = fixHour(atan2(cos(e) * sin(L), cos(L)) / 15);
    return { decl: asin(sin(e) * sin(L)), eqt: q / 15 - RA };
  }

  /* Returns {fajr,sunrise,dhuhr,asr,asr2,maghrib,isha} as fractional local hours for the given date.
     asr2 = shadow twice the object's length: end of the chosen Asr time (Hanbali). */
  function prayerHours(date, lat, lng, tz, ramadan) {
    var jd = julian(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lng / (15 * 24);
    function midDay(t) { return fixHour(12 - sunPosition(jd + t).eqt); }
    function angleTime(angle, t, ccw) {
      var decl = sunPosition(jd + t).decl;
      var noon = midDay(t);
      var v = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
      if (v > 1 || v < -1) return NaN;
      return noon + (ccw ? -1 : 1) * acos(v) / 15;
    }
    function asrTime(factor, t) {
      var decl = sunPosition(jd + t).decl;
      var angle = -acot(factor + tan(Math.abs(lat - decl)));
      return angleTime(angle, t, false);
    }
    var t = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, asr2: 15, maghrib: 18, isha: 18 };
    var i, k;
    for (i = 0; i < 2; i++) {
      var f = {};
      for (k in t) f[k] = t[k] / 24;
      t.fajr = angleTime(18.5, f.fajr, true);
      t.sunrise = angleTime(0.833, f.sunrise, true);
      t.dhuhr = midDay(f.dhuhr);
      t.asr = asrTime(1, f.asr);
      t.asr2 = asrTime(2, f.asr2);
      t.maghrib = angleTime(0.833, f.maghrib, false);
      t.isha = t.maghrib; /* placeholder, replaced below */
    }
    var adj = tz - lng / 15;
    var out = {};
    for (k in t) out[k] = t[k] + adj;
    out.dhuhr += 1 / 60;           /* small safety margin after zenith */
    out.isha = out.maghrib + (ramadan ? 120 : 90) / 60;  /* Umm al-Qura */
    return out;
  }

  function hoursToDate(base, h) {
    var d = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 0, 0, 0, 0);
    return new Date(d.getTime() + Math.round(h * 3600000));
  }

  /* Prayer times for a date, as Date objects. */
  function prayerTimes(date, cfg, ramadan) {
    var tz = -date.getTimezoneOffset() / 60;
    var h = prayerHours(date, cfg.lat, cfg.lng, tz, ramadan);
    var out = {};
    for (var k in h) out[k] = hoursToDate(date, h[k]);
    return out;
  }

  /* ---- Hijri ---- */
  var HMONTHS = ['محرّم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوّال', 'ذو القعدة', 'ذو الحجة'];

  function kuwaiti(date) { /* fallback arithmetic calendar */
    var day = date.getDate(), month = date.getMonth(), year = date.getFullYear();
    var m = month + 1, y = year;
    if (m < 3) { y -= 1; m += 12; }
    var a = Math.floor(y / 100), b = 2 - a + Math.floor(a / 4);
    if (y < 1583) b = 0;
    if (y === 1582) { if (m > 10) b = -10; if (m === 10) { b = 0; if (day > 4) b = -10; } }
    var jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524;
    b = 0;
    if (jd > 2299160) { a = Math.floor((jd - 1867216.25) / 36524.25); b = 1 + a - Math.floor(a / 4); }
    var bb = jd + b + 1524, cc = Math.floor((bb - 122.1) / 365.25), dd = Math.floor(365.25 * cc);
    var ee = Math.floor((bb - dd) / 30.6001);
    var wd = Math.floor(jd + 1) % 7;
    var iyear = 10631 / 30, epoch = 1948084, shift1 = 8.01 / 60;
    var z = jd - epoch, cyc = Math.floor(z / 10631);
    z = z - 10631 * cyc;
    var j = Math.floor((z - shift1) / iyear);
    var iy = 30 * cyc + j;
    z = z - Math.floor(j * iyear + shift1);
    var im = Math.floor((z + 28.5001) / 29.5);
    if (im === 13) im = 12;
    var id = z - Math.floor(29.5001 * im - 29);
    return { y: iy, m: im - 1, d: id };
  }

  /* تقويم أم القرى الرسمي ١٤٤٠–١٤٦٩هـ: كل سنة ٣ خانات hex = ١٢ بتاً (١ = الشهر ٣٠ يوماً، ٠ = ٢٩)،
     تبدأ من ١ محرّم ١٤٤٠ = ١١ سبتمبر ٢٠١٨. وُلِّد من بيانات ICU (islamic-umalqura) لأن WebView القديم لا يدعمها */
  var UQ0 = Date.UTC(2018, 8, 11), UQ_HEX = '5d4ada55aaab595749764baa5b52b6a56e4db25b52b6a5ad2ae92f49764b6a56acad655d49da4dd16d955aa5b4';
  function uqTable(date) {
    var dn = Math.round((Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) - UQ0) / 86400000), y, m;
    if (dn < 0) return null;
    for (y = 0; y * 3 < UQ_HEX.length; y++) {
      var bits = parseInt(UQ_HEX.substr(y * 3, 3), 16);
      for (m = 0; m < 12; m++) {
        if (y * 12 + m >= 359) return null;
        var len = (bits >> (11 - m)) & 1 ? 30 : 29;
        if (dn < len) return { y: 1440 + y, m: m, d: dn + 1, src: 'table' };
        dn -= len;
      }
    }
    return null;
  }

  function hijri(date) {
    var tb = uqTable(date);
    if (tb) return tb;
    try {
      var s = new Intl.DateTimeFormat('en-US-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric' }).format(date);
      var m = s.match(/(\d+)\D+(\d+)\D+(\d+)/);
      if (m) {
        var mo = parseInt(m[1], 10), da = parseInt(m[2], 10), ye = parseInt(m[3], 10);
        if (ye > 1300 && ye < 1700 && mo >= 1 && mo <= 12) return { y: ye, m: mo - 1, d: da, src: 'umalqura' };
      }
    } catch (e) { }
    var k = kuwaiti(date); k.src = 'arith'; return k;
  }

  var AR_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  var AR_MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  var DIGITS = '٠١٢٣٤٥٦٧٨٩';
  function ar(n) { return String(n).replace(/\d/g, function (d) { return DIGITS.charAt(d); }); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function hm(d) { return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function parseYmd(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }

  w.Lib = {
    prayerTimes: prayerTimes, hijri: hijri, HMONTHS: HMONTHS,
    AR_DAYS: AR_DAYS, AR_MONTHS: AR_MONTHS, ar: ar, pad: pad, ymd: ymd, hm: hm, parseYmd: parseYmd
  };
})(window);
