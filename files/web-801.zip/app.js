/* Otmo Frame — main logic. ES5 only (Android 6 WebView). */
(function (w) {
  var L = w.Lib, ar = L.ar, pad = L.pad, ymd = L.ymd, hm = L.hm;
  var HF = w.HomeFrame || null;
  function $(id) { return document.getElementById(id); }
  function each(list, fn) { for (var i = 0; i < list.length; i++) fn(list[i], i); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- التخزين ---------- */
  var Store = {
    get: function (k, def) {
      try { var v = localStorage.getItem('otmo.' + k); if (v) return JSON.parse(v); } catch (e) { }
      if (HF) { try { var s = HF.readFile(k + '.json'); if (s) return JSON.parse(s); } catch (e2) { } }
      return def;
    },
    set: function (k, v) {
      var s = JSON.stringify(v);
      try { localStorage.setItem('otmo.' + k, s); } catch (e) { }
      if (HF) { try { HF.saveFile(k + '.json', s); } catch (e2) { } }
    }
  };

  var cfg = Store.get('cfg', null) || {};
  (function defaults() {
    var d = { city: 'مكة المكرمة', lat: 21.4225, lng: 39.8262, forceRamadan: false, rotate: true,
      kids: [{ id: 'k1', name: 'الابن الأول' }, { id: 'k2', name: 'الابن الثاني' }],
      name: 'إطار البيت', tabs: ['home', 'prayers', 'adhkar', 'cal', 'events', 'bdays', 'tasks', 'alarm', 'kids', 'board'],
      /* الأذكار التلقائية: min = دقائق بعد الفجر (m) أو العصر (e)، أو at = وقت ثابت يحدده الأدمن */
      adh: { m: { on: true, min: 40, at: '' }, e: { on: true, min: 40, at: '' } } };
    for (var k in d) if (cfg[k] === undefined) cfg[k] = d[k];
    /* صفحة المهام أُضيفت بعد اختيار الصفحات: تظهر مرة واحدة تلقائياً، ثم يحترم اختيار الأدمن */
    if (!cfg.tasksTab) { if (cfg.tabs.indexOf('tasks') < 0) cfg.tabs.push('tasks'); cfg.tasksTab = true; }
    cfg.kids.forEach(function (kd) { if (kd.name === 'الطفل الأول') kd.name = 'الابن الأول'; if (kd.name === 'الطفل الثاني') kd.name = 'الابن الثاني'; });
  })();
  var events = Store.get('events', []);
  /* مواعيد تقويم قوقل (للقراءة فقط): تُجلب من الرابط السري المحفوظ في الجهاز وتُدمج مع مواعيد الإطار */
  var gcal = Store.get('gcal', null) || {}, gEvents = gcal.items || [];
  function allEvents() { return gEvents.length ? events.concat(gEvents) : events; }
  var records = Store.get('records', []).filter(function (r) { return r && r.k && r.p; });
  var board = Store.get('board', []);
  function saveCfg() { Store.set('cfg', cfg); }
  function saveEvents() { Store.set('events', events); publishSoon(); ensureTts(); }
  function saveRecords() { recMap = null; kidFirst = null; Store.set('records', records); }

  /* ---------- الوقت والصلاة ---------- */
  var PR = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  var PR_AR = { fajr: 'الفجر', sunrise: 'الشروق', dhuhr: 'الظهر', asr: 'العصر', maghrib: 'المغرب', isha: 'العشاء' };

  function ramadanOn(now) { return !!cfg.forceRamadan || L.hijri(now || new Date()).m === 8; }
  /* العيد: أول ثلاثة أيام من عيد الفطر (١–٣ شوال) وعيد الأضحى (١٠–١٢ ذو الحجة) حسب أم القرى؛ ويُفعَّل يدوياً من القائمة إن اختلفت الرؤية */
  function eidOf(now) {
    var h = L.hijri(now || new Date());
    if (h.m === 9 && h.d <= 3) return { k: 'fitr', day: h.d };
    if (h.m === 11 && h.d >= 10 && h.d <= 12) return { k: 'adha', day: h.d - 9 };
    if (cfg.forceEid) return { k: h.m >= 10 && h.m <= 11 ? 'adha' : 'fitr', day: 1 };
    return null;
  }
  var EID_DAY = ['', 'أول', 'ثاني', 'ثالث'];
  var tcache = {};
  function times(date) {
    var r = ramadanOn(date);
    var key = ymd(date) + (r ? 'r' : '') + cfg.lat + cfg.lng;
    if (!tcache[key]) { if (Object.keys(tcache).length > 30) tcache = {}; tcache[key] = L.prayerTimes(date, cfg, r); }
    return tcache[key];
  }
  function nextPrayer(now) {
    var t = times(now), i;
    for (i = 0; i < PR.length; i++) if (t[PR[i]] > now) return { name: PR[i], at: t[PR[i]] };
    var tm = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    return { name: 'fajr', at: times(tm).fajr };
  }
  function prevPrayerTime(now) {
    var t = times(now), i, best = null;
    for (i = 0; i < PR.length; i++) if (t[PR[i]] <= now) best = t[PR[i]];
    if (best) return best;
    return times(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)).isha;
  }
  function dayOff(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); }
  function atTime(date, t) { var p = t.split(':'); return new Date(date.getFullYear(), date.getMonth(), date.getDate(), +p[0], +p[1]); }

  /* ---------- أوقات إضافية في صفحة الصلاة (بلا تنبيه) ----------
     الضحى بعد الشروق بربع ساعة · قيام الليل = بداية الثلث الأخير بين المغرب والفجر · التراويح بعد العشاء في رمضان ·
     صلاة العيد بعد الشروق بربع ساعة في أول يوم. إن وُجد في التقويم (قوقل أو الإطار) موعد باسمها يُؤخذ وقته بدلاً من التقدير */
  function calTime(date, re) {
    var hit = null;
    each(eventsOn(date), function (e) { if (!hit && e.time && !isBd(e) && re.test(e.title)) hit = atTime(date, e.time); });
    return hit;
  }
  function qiyamOf(now) {
    var t = times(now), a, b;
    if (now < t.fajr) { a = times(dayOff(now, -1)).maghrib; b = t.fajr; } else { a = t.maghrib; b = times(dayOff(now, 1)).fajr; }
    return new Date(b.getTime() - (b - a) / 3);
  }
  function extraTimes(now) {
    var t = times(now), x = { duha: new Date(t.sunrise.getTime() + 15 * 60000), qiyam: qiyamOf(now) }, e = eidOf(now);
    if (ramadanOn(now) && !e) x.taraweeh = calTime(now, /تراويح/) || new Date(t.isha.getTime() + 20 * 60000);
    if (e && e.day === 1) x.eid = calTime(now, /صلاة العيد/) || x.duha;
    return x;
  }
  /* الصلوات الطارئة (الاستسقاء، الكسوف، الخسوف…) تأتي من تقويم قوقل أو مواعيد الإطار: كل موعد اليوم أو غداً عنوانه فيه «صلاة» */
  var SPECIAL_RE = /صلاة|صلاه|استسقاء|كسوف|خسوف/, SPECIAL_SKIP = /تراويح|صلاة العيد/;
  function specialPrayers(now) {
    var out = [];
    each([0, 1], function (i) {
      var d = dayOff(now, i);
      each(eventsOn(d), function (e) { if (!isBd(e) && SPECIAL_RE.test(e.title) && !SPECIAL_SKIP.test(e.title)) out.push({ e: e, in: i, at: e.time ? atTime(d, e.time) : null }); });
    });
    return out;
  }
  function fmtCount(ms) {
    var s = Math.max(0, Math.floor(ms / 1000));
    return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s % 3600 / 60)) + ':' + pad(s % 60);
  }

  /* ---------- المواعيد ---------- */
  function occursOn(ev, date) {
    var b = L.parseYmd(ev.date), d0 = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    if (ev.repeat === 'none' || !ev.repeat) return ymd(b) === ymd(d0);
    if (d0 < b) return false;
    if (ev.repeat === 'weekly') return d0.getDay() === b.getDay();
    if (ev.repeat === 'monthly') return d0.getDate() === b.getDate();
    if (ev.repeat === 'yearly') return d0.getDate() === b.getDate() && d0.getMonth() === b.getMonth();
    return false;
  }
  function eventsOn(date) {
    var out = [];
    each(allEvents(), function (e) { if (occursOn(e, date)) out.push(e); });
    out.sort(function (a, b) { return (a.time || '00:00') < (b.time || '00:00') ? -1 : 1; });
    return out;
  }
  function ageOf(e, date) { return date.getFullYear() - L.parseYmd(e.date).getFullYear(); }
  /* أيام الميلاد تُحفظ مع المواعيد (kind: 'birthday') لكنها تُعرض في صفحتها الخاصة */
  function isBd(e) { return e.kind === 'birthday'; }
  function isAppt(e) { return !isBd(e); }
  function bdYearKnown(e) { return L.parseYmd(e.date).getFullYear() > 1900; }
  function upcoming(days, limit, keep) {
    var out = [], now = new Date(), i;
    for (i = 0; i < days && out.length < limit; i++) {
      var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
      each(eventsOn(d), function (e) { if (!keep || keep(e)) out.push({ e: e, date: d, in: i }); });
    }
    return out.slice(0, limit);
  }
  function whenText(i) { return i === 0 ? 'اليوم' : i === 1 ? 'غداً' : 'بعد ' + ar(i) + ' يوم'; }
  function dateText(d) { return L.AR_DAYS[d.getDay()] + ' ' + ar(d.getDate()) + ' ' + L.AR_MONTHS[d.getMonth()]; }

  /* ---------- الشبكة ---------- */
  var cbs = {}, cbn = 0;
  w.__cb = function (id, ok, body) { var f = cbs[id]; delete cbs[id]; if (f) f(ok, body); };
  function httpGet(url, cb) {
    if (HF && HF.httpGet) { var id = 'c' + (++cbn); cbs[id] = cb; HF.httpGet(url, id); return; }
    try {
      fetch(url).then(function (r) { return r.text(); }).then(function (t) { cb(true, t); }, function (e) { cb(false, String(e)); });
    } catch (e) { cb(false, String(e)); }
  }

  /* ---------- الطقس ---------- */
  var WCODE = { 0: 'صافٍ', 1: 'غالباً صافٍ', 2: 'غائم جزئياً', 3: 'غائم', 45: 'ضباب', 48: 'ضباب كثيف', 51: 'رذاذ خفيف', 53: 'رذاذ', 55: 'رذاذ كثيف',
    61: 'أمطار خفيفة', 63: 'أمطار', 65: 'أمطار غزيرة', 71: 'ثلوج خفيفة', 73: 'ثلوج', 75: 'ثلوج كثيفة', 80: 'زخات مطر', 81: 'زخات مطر', 82: 'زخات غزيرة',
    95: 'عاصفة رعدية', 96: 'عاصفة رعدية وبَرَد', 99: 'عاصفة رعدية وبَرَد' };
  function loadWeather() {
    var u = 'https://api.open-meteo.com/v1/forecast?latitude=' + cfg.lat + '&longitude=' + cfg.lng +
      '&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m' +
      '&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1';
    httpGet(u, function (ok, body) {
      $('wcity').textContent = cfg.city;
      if (!ok) { $('wdesc').textContent = 'الطقس غير متاح'; return; }
      try {
        var j = JSON.parse(body), c = j.current, dly = j.daily;
        $('wtemp').textContent = Math.round(c.temperature_2m) + '°';
        $('wdesc').textContent = WCODE[c.weather_code] || '—';
        var wc = c.weather_code;
        $('wicon').textContent = wc <= 1 ? '☀' : wc === 2 ? '⛅' : wc === 3 ? '☁' : wc >= 95 ? '⚡' : wc >= 71 && wc <= 77 ? '❄' : wc >= 45 && wc <= 48 ? '☁' : '☂';
        $('wsub').textContent = 'يحسّ كـ ' + ar(Math.round(c.apparent_temperature)) + '° · رطوبة ' + ar(Math.round(c.relative_humidity_2m)) + '٪ · رياح ' + ar(Math.round(c.wind_speed_10m)) +
          ' كم/س · العظمى ' + ar(Math.round(dly.temperature_2m_max[0])) + '° الصغرى ' + ar(Math.round(dly.temperature_2m_min[0])) + '°';
      } catch (e) { $('wdesc').textContent = 'الطقس غير متاح'; }
    });
  }

  /* ---------- الوقت بنظام ١٢ ساعة (ص/م) + قوائم الاختيار ---------- */
  function t12(t, latin) {
    if (!t) return "";
    var p = t.split(":"), h = +p[0], m = p[1], h12 = h % 12 || 12;
    return (latin ? h12 : ar(h12)) + ":" + (latin ? m : ar(m)) + " " + (h < 12 ? "ص" : "م");
  }
  function fillTimeSelects(hid, mid, withNone) {
    var h = $(hid), m = $(mid), i, o;
    if (withNone) { o = document.createElement("option"); o.value = ""; o.textContent = "بدون وقت"; h.appendChild(o); }
    for (i = 1; i <= 12; i++) { o = document.createElement("option"); o.value = i; o.textContent = i; h.appendChild(o); }
    for (i = 0; i < 60; i++) { o = document.createElement("option"); o.value = pad(i); o.textContent = pad(i); m.appendChild(o); }
  }
  function getTimeFields(hid, mid, apid) {
    var h = $(hid).value; if (h === "") return "";
    var hh = (+h % 12) + ($(apid).value === "pm" ? 12 : 0);
    return pad(hh) + ":" + $(mid).value;
  }
  function setTimeFields(hid, mid, apid, t) {
    if (!t) { $(hid).value = ""; $(mid).value = "00"; $(apid).value = "am"; return; }
    var p = t.split(":"), h = +p[0];
    $(hid).value = String(h % 12 || 12); $(mid).value = p[1]; $(apid).value = h < 12 ? "am" : "pm";
  }

  /* ---------- النطق: تشكيل الأسماء والعبارات ليخرج النطق سليماً (ولفظ الجلالة) ---------- */
  var NAMES = { "محمد": "مُحَمَّد", "احمد": "أَحْمَد", "عبدالله": "عَبْدُ اللَّه", "عبد الله": "عَبْدُ اللَّه", "عبدالرحمن": "عَبْدُ الرَّحْمَن", "عبد الرحمن": "عَبْدُ الرَّحْمَن", "عبدالعزيز": "عَبْدُ الْعَزِيز", "عبد العزيز": "عَبْدُ الْعَزِيز", "عبدالملك": "عَبْدُ الْمَلِك", "سلمان": "سَلْمَان", "فهد": "فَهْد", "خالد": "خَالِد", "سعد": "سَعْد", "سعود": "سُعُود", "ناصر": "نَاصِر", "نواف": "نَوَاف", "فيصل": "فَيْصَل", "تركي": "تُرْكِي", "بندر": "بَنْدَر", "ماجد": "مَاجِد", "ياسر": "يَاسِر", "يوسف": "يُوسُف", "ابراهيم": "إِبْرَاهِيم", "اسماعيل": "إِسْمَاعِيل", "عمر": "عُمَر", "عثمان": "عُثْمَان", "علي": "عَلِي", "حسن": "حَسَن", "حسين": "حُسَيْن", "مازن": "مَازِن", "زياد": "زِيَاد", "سامي": "سَامِي", "طلال": "طَلَال", "وليد": "وَلِيد", "هشام": "هِشَام", "انس": "أَنَس", "بدر": "بَدْر", "راشد": "رَاشِد", "ريان": "رَيَّان", "صالح": "صَالِح", "سلطان": "سُلْطَان", "مشعل": "مِشْعَل", "مشاري": "مِشَارِي", "نايف": "نَايِف", "منصور": "مَنْصُور", "جابر": "جَابِر", "حمد": "حَمَد", "عادل": "عَادِل", "كريم": "كَرِيم", "قسورة": "قَسْوَرَة", "سارة": "سَارَة", "نورة": "نُورَة", "ريم": "رِيم", "لينا": "لِينَا", "جود": "جُود", "لمى": "لَمَى", "ليان": "لِيَان", "مها": "مَهَا", "هند": "هِنْد", "فاطمة": "فَاطِمَة", "عائشة": "عَائِشَة", "مريم": "مَرْيَم", "زينب": "زَيْنَب", "رهف": "رَهَف", "غدير": "غَدِير", "اروى": "أَرْوَى", "تالية": "تَالِيَة", "سلافة": "سُلَافَة", "العنود": "الْعَنُود", "دانة": "دَانَة", "شهد": "شَهَد", "جوري": "جُورِي", "ملك": "مَلَك", "ريماس": "رِيمَاس", "الجوهرة": "الْجَوْهَرَة", "منيرة": "مُنِيرَة", "هيا": "هَيَا", "رند": "رَنْد", "لجين": "لُجَيْن", "امجد": "أَمْجَد", "ميار": "مَيَاار" /* الألف الممدودة تمنع الصوت من تشديد الياء (اختارها الأهل بالسماع) */, "حور": "حُور", "حوراء": "حَوْرَاء", "رفاء": "رَفَاءْ", "ثناء": "ثَنَاءْ", "رهاء": "رَهَاءْ", "رائف": "رَائِف", "رفا": "رَفَا", "سما": "سَمَا", "رجا": "رَجَا" };
  function nameSpoken(name) {
    if (/[\u064B-\u065F\u0670]/.test(name)) return name;
    var k = name.replace(/^\s+|\s+$/g, "").replace(/[أإآ]/g, "ا").replace(/ى$/, "ى");
    return NAMES[k] || name;
  }
  var PR_SPOKEN = { fajr: "الْفَجْرِ", dhuhr: "الظُّهْرِ", asr: "الْعَصْرِ", maghrib: "الْمَغْرِبِ", isha: "الْعِشَاءِ" };

  /* ---------- الصفحات ---------- */
  var PAGES = ['home', 'prayers', 'adhkar', 'cal', 'events', 'bdays', 'tasks', 'alarm', 'kids', 'board'];
  var cur = 'home', lastTouch = 0;
  /* كل إطار يعرض الصفحات المختارة له فقط (تُضبط من الجوال)؛ الرئيسية دائماً موجودة */
  function tabOn(p) { return p === 'home' || !cfg.tabs || cfg.tabs.indexOf(p) >= 0; }
  function navPages() { return PAGES.filter(tabOn); }
  function applyTabs() {
    each(document.querySelectorAll('#nav button'), function (b) { b.style.display = tabOn(b.getAttribute('data-p')) ? '' : 'none'; });
    if (!tabOn(cur)) show('home');
  }
  function show(name) {
    if (!tabOn(name)) name = 'home';
    cur = name;
    each(document.querySelectorAll('.page'), function (p) { p.className = 'page' + (p.id === 'p-' + name ? ' active' : ''); });
    each(document.querySelectorAll('#nav button'), function (b) { b.className = b.getAttribute('data-p') === name ? 'on' : ''; });
    if (name === 'prayers') renderPrayers();
    if (name === 'adhkar') renderAdhkar(true);
    if (name === 'cal') { if (calAuto || Date.now() - calTouched > 120000) calToday(); renderCal(); }
    if (name === 'events') renderEvents();
    if (name === 'bdays') renderBdays();
    if (name === 'tasks') renderTasks();
    if (name === 'kids') renderKids();
    if (name === 'alarm') { renderAlarms(); renderTimer(); renderSw(); }
    if (name === 'board') renderBoard();
    if (name === 'home') renderHomeEvents();
    if (name !== 'adhkar') stopSpeak();
    updatePill();
  }
  function rotationList() {
    var h = new Date().getHours(), list = ['home', 'prayers', 'cal', 'events', 'bdays', 'kids', 'board'];
    if ((h >= 5 && h < 9) || (h >= 15 && h < 19)) list.splice(2, 0, 'adhkar');
    if (!board.length) list.splice(list.indexOf('board'), 1);
    if (cfg.kids.length) list.splice(list.indexOf('bdays') + 1, 0, 'tasks');
    return list.filter(tabOn);
  }

  /* ---------- الرئيسية ---------- */
  function tickClock() {
    var now = new Date();
    if (w.clockOk && !w.clockOk()) {
      /* بعد إعادة التشغيل: لا نعرض وقتاً خاطئاً ولا نطلق أي تنبيه حتى يُضبط الوقت من الإنترنت */
      $('hhmm').textContent = '--:--'; $('ss').textContent = '';
      $('dayname').textContent = 'جارٍ ضبط الوقت…'; $('hijdate').textContent = ''; $('gregdate').textContent = 'يتطلب اتصالاً بالإنترنت';
      return;
    }
    var h = L.hijri(now);
    $('hhmm').textContent = hm(now);
    $('ss').textContent = pad(now.getSeconds());
    $('dayname').textContent = 'يوم ' + L.AR_DAYS[now.getDay()];
    $('hijdate').textContent = ar(h.d) + ' ' + L.HMONTHS[h.m] + ' ' + ar(h.y) + 'هـ';
    $('gregdate').textContent = ar(now.getDate()) + ' ' + L.AR_MONTHS[now.getMonth()] + ' ' + ar(now.getFullYear()) + 'م';
    if (!cfg.repFrom) { cfg.repFrom = ymd(now); saveCfg(); }
    var rm = ramadanOn(now);
    var eid = eidOf(now);
    document.body.className = (eid ? 'eid fest ' : rm ? 'ramadan fest ' : '') + (w.innerWidth >= w.innerHeight ? 'land' : 'port') + ($('tpill').className ? ' pill' : '');
    tickTimer(); updatePill(); tickSound();
    if (cur === 'alarm' && alSeg === 'timer' && tm) renderTimer();
    var np = nextPrayer(now);
    $('nextname').textContent = PR_AR[np.name];
    $('nexttime').textContent = hm(np.at);
    $('nextcount').textContent = fmtCount(np.at - now);
    var prev = prevPrayerTime(now), span = np.at - prev;
    $('nextbar').style.width = (span > 0 ? Math.max(0, Math.min(100, (now - prev) / span * 100)) : 0) + '%';
    if (rm && !eid) tickRamadan(now, np);
    if (eid) {
      $('e-title').textContent = eid.k === 'fitr' ? 'عيد فطر مبارك' : 'عيد أضحى مبارك';
      $('e-day').textContent = EID_DAY[eid.day] + ' أيام عيد ' + (eid.k === 'fitr' ? 'الفطر' : 'الأضحى');
    }
    tickCalls(now);
    tickAlarms(now);
    tickTasks(now);
    tickEvents(now);
    tickAdhAuto(now);
    tickUpdate(now);
    if (cur === 'prayers' && now.getSeconds() % 10 === 0) renderPrayers();
  }
  /* بطاقة رمضان: النهار → عدّاد الإفطار وشريط الصيام؛ بعد المغرب بقليل → دعاء الإفطار؛ الليل → عدّاد الإمساك */
  function tickRamadan(now, np) {
    var t = times(now), imsak = new Date(t.fajr.getTime() - 10 * 60000), iftar = t.maghrib, h = L.hijri(now);
    var tm = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1), imsakNext = now < imsak ? imsak : new Date(times(tm).fajr.getTime() - 10 * 60000);
    var lbl, count = '', bar = -1, dua = false;
    if (now < imsak) { lbl = 'يبقى على الإمساك'; count = fmtCount(imsak - now); }
    else if (now < iftar) { lbl = 'يبقى على الإفطار'; count = fmtCount(iftar - now); bar = (now - imsak) / (iftar - imsak) * 100; }
    else if (now - iftar < 45 * 60000) { lbl = 'تقبّل الله صيامكم · دعاء الإفطار'; dua = true; }
    else { lbl = 'تقبّل الله صيامكم · يبقى على الإمساك'; count = fmtCount(imsakNext - now); }
    $('r-day').textContent = h.m === 8 ? 'اليوم ' + ar(h.d) + ' من رمضان' : '';
    $('r-lbl').textContent = lbl;
    $('r-count').textContent = count; $('r-count').style.display = count ? '' : 'none';
    $('r-dua').style.display = dua ? '' : 'none';
    $('r-barw').style.display = bar >= 0 ? '' : 'none'; if (bar >= 0) $('r-bar').style.width = Math.max(0, Math.min(100, bar)) + '%';
    $('r-imsak').textContent = hm(imsakNext);
    $('r-iftar').textContent = hm(iftar);
    $('r-nextname').textContent = 'القادمة: ' + PR_AR[np.name];
    $('r-next').textContent = hm(np.at);
  }
  /* الرئيسية: المواعيد فقط (بلا أيام الميلاد) — اسم الموعد وتاريخه */
  function renderHomeEvents() {
    var up = upcoming(60, 3, isAppt), html = '';
    each(up, function (u) {
      html += '<div class="e"><span>' + esc(u.e.title) + '</span><span>' + dateText(u.date) + (u.e.time ? ' · ' + t12(u.e.time) : '') + '</span></div>';
    });
    $('evmini').innerHTML = html || '<div class="none">لا توجد مواعيد قادمة</div>';
  }

  /* ---------- المواقيت ---------- */
  /* ---------- الكسوف والخسوف من جدول eclipses.js (بلا إنترنت) ----------
     الخسوف يُعرض إن وقع ظلّ القمر (جزئي أو كلي) بين المغرب والفجر في مدينة الإطار؛ بعد الفجر لا تُشرع صلاته.
     الكسوف من حسابات المدينة نفسها، أو أقرب مدينة في الجدول إن كانت ضمن ٣٠٠ كم، ويُقصّ على ما بين الشروق والمغرب */
  function eclCity() {
    var best = -1, bd = 1e9;
    each(CITIES, function (c, i) {
      var dy = (c[1] - cfg.lat) * 111, dx = (c[2] - cfg.lng) * 111 * Math.cos(cfg.lat * Math.PI / 180), d = Math.sqrt(dx * dx + dy * dy);
      if (d < bd) { bd = d; best = i; }
    });
    return bd <= 300 ? best : -1;
  }
  var ECL_KIND = { t: 'كلي', a: 'حلقي', p: 'جزئي' };
  function eclipsesNear(now, days) {
    var E = w.ECLIPSES, out = [], from = dayOff(now, -1), to = dayOff(now, days + 1), ci = eclCity();
    if (!E) return out;
    each(E.l, function (x) {
      var u1 = new Date(x[1] * 1000), u4 = new Date(x[2] * 1000);
      if (u4 < from || u1 > to) return;
      var d = dayOff(u1, 0), ns, ne;
      if (u1.getHours() < 12) { ns = times(dayOff(d, -1)).maghrib; ne = times(d).fajr; } else { ns = times(d).maghrib; ne = times(dayOff(d, 1)).fajr; }
      var s = u1 > ns ? u1 : ns, e = u4 < ne ? u4 : ne;
      if (s < e) out.push({ title: 'صلاة الخسوف', note: 'خسوف ' + ECL_KIND[x[0]] + ' للقمر', at: s, end: e });
    });
    if (ci >= 0) each(E.s, function (x) {
      each(x[1], function (c) {
        if (c[0] !== ci) return;
        var b = new Date(c[1] * 1000), f = new Date(c[2] * 1000), t = times(b);
        if (f < from || b > to) return;
        var s = b > t.sunrise ? b : t.sunrise, e = f < t.maghrib ? f : t.maghrib;
        if (s < e) out.push({ title: 'صلاة الكسوف', note: 'كسوف ' + ECL_KIND[c[4]] + ' للشمس ' + c[3] + '%', at: s, end: e });
      });
    });
    return out.filter(function (x) { return x.end > dayOff(now, 0) && x.at < to; });
  }
  function inDaysText(d, now) {
    var n = Math.round((dayOff(d, 0) - dayOff(now, 0)) / 86400000);
    return n <= 0 ? 'اليوم' : n === 1 ? 'غداً' : 'بعد ' + daysText(n);
  }

  /* ---------- المواقيت: أيقونة لكل صلاة، وشريط يمتلئ من الصلاة السابقة حتى دخول وقتها مع «باقي …» ----------
     شريط الفجر يبدأ من منتصف الليل، فيبدأ الشريط من جديد كل يوم؛ وبعد العشاء تكون الأشرطة ممتلئة حتى منتصف الليل */
  var PR_ICON = {
    fajr: '<path d="M3 19h18"/><path d="M7.5 19a4.5 4.5 0 0 1 9 0"/><path d="M18 4.5l.7 1.6 1.6.7-1.6.7-.7 1.6-.7-1.6-1.6-.7 1.6-.7z"/>',
    sunrise: '<path d="M3 19h18"/><path d="M7 19a5 5 0 0 1 10 0"/><path d="M12 4v3M5.2 8.8l1.8 1.8M18.8 8.8 17 10.6"/>',
    dhuhr: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/>',
    asr: '<circle cx="9" cy="10" r="3.5"/><path d="M9 3v1.6M2.5 10h1.6M4.4 5.4l1.1 1.1M13.6 5.4l-1.1 1.1"/><path d="M3 20h18"/><path d="M12 20l6-5"/>',
    maghrib: '<path d="M3 17h18"/><path d="M7 17a5 5 0 0 1 10 0"/><path d="M12 3v5M9.6 5.8 12 8.2l2.4-2.4"/><path d="M7 21h10"/>',
    isha: '<path d="M19 14.5A7.5 7.5 0 1 1 9.5 5a6 6 0 0 0 9.5 9.5z"/><path d="M18 3.5l.6 1.4 1.4.6-1.4.6-.6 1.4-.6-1.4-1.4-.6 1.4-.6z"/>',
    imsak: '<path d="M3 19h18"/><path d="M15.5 6.5A5 5 0 1 0 19 13a4 4 0 0 1-3.5-6.5z"/>',
    duha: '<circle cx="12" cy="14" r="3"/><path d="M12 7.5v1.6M6 14H4.4M19.6 14H18M7.8 9.8l-1.1-1.1M16.2 9.8l1.1-1.1"/><path d="M3 20h18"/>',
    eid: '<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6L3.3 9.3l6.1-.7z"/>',
    taraweeh: '<path d="M12 2.5v2"/><path d="M9 6.5h6l1.2 2.2v7.6L15 18.5H9l-1.2-2.2V8.7z"/><path d="M10 21h4M12 10v4.5"/>',
    qiyam: '<path d="M16 13.5A6 6 0 1 1 10.5 6a4.8 4.8 0 0 0 5.5 7.5z"/><path d="M17.5 4l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2-1.2-.5 1.2-.5zM20 9.5l.3.8.8.3-.8.3-.3.8-.3-.8-.8-.3.8-.3z"/>',
    special: '<circle cx="12" cy="12" r="7.5"/><path d="M14.5 5a7.5 7.5 0 0 1 0 14 9 9 0 0 0 0-14z" class="fl"/>'
  };
  function prIcon(k) { return '<span class="pic"><svg viewBox="0 0 24 24">' + PR_ICON[k] + '</svg></span>'; }
  /* خروج وقت كل صلاة (المذهب الحنبلي المعمول به في السعودية): الفجر بشروق الشمس، الظهر بدخول العصر،
     العصر المختار حين يصير ظل الشيء مثليه ثم وقت ضرورة إلى المغرب، المغرب بدخول العشاء،
     العشاء المختار بانتهاء الثلث الأول من الليل (من المغرب إلى الفجر) ثم وقت ضرورة إلى الفجر */
  function prayerEnd(k, now) {
    var t = times(now);
    if (k === 'fajr') return { at: t.sunrise };
    if (k === 'dhuhr') return { at: t.asr };
    if (k === 'asr') return { at: t.asr2, need: t.maghrib, nn: 'المغرب' };
    if (k === 'maghrib') return { at: t.isha };
    var f = times(dayOff(now, 1)).fajr;
    return { at: new Date(t.maghrib.getTime() + (f - t.maghrib) / 3), need: f, nn: 'الفجر' };
  }
  function untilText(ms) { var m = Math.ceil(ms / 60000); return m < 60 ? countAr(m, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة') : durText(m); }
  function leftText(ms) { var m = Math.ceil(ms / 60000); return 'باقي ' + (m < 60 ? countAr(m, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة') : durText(m)); }
  function renderPrayers() {
    var now = new Date(), t = times(now), np = nextPrayer(now), html = '', prev = dayOff(now, 0);
    var rmd = ramadanOn(now), ims = new Date(t.fajr.getTime() - 10 * 60000), x = extraTimes(now);
    function exRow(icon, name, note, at, cls) {
      return '<div class="prow ex' + (cls || '') + '">' + prIcon(icon) + '<div class="pmid"><b>' + name + '</b>' + (note ? '<small>' + note + '</small>' : '') + '</div><b class="ptime">' + (at ? hm(at) : '—') + '</b></div>';
    }
    if (rmd) html += exRow('imsak', 'الإمساك', 'قبل الفجر بعشر دقائق', ims, ' fe' + (ims < now ? ' past' : ''));
    each(['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'], function (k) {
      var at = t[k], past = at <= now, pct = past ? 100 : now <= prev ? 0 : (now - prev) / (at - prev) * 100, st = '', note;
      if (!past) note = leftText(at - now);
      else if (k === 'sunrise') { note = 'أشرقت الشمس'; st = ' past'; }
      else {
        var en = prayerEnd(k, now);
        if (now < en.at) { note = 'دخل وقتها · يخرج بعد ' + untilText(en.at - now) + ' (' + t12(hm(en.at)) + ')'; st = ' cur'; }
        else if (en.need && now < en.need) { note = 'خرج وقتها المختار · وقت الضرورة حتى ' + en.nn; st = ' past out'; }
        else { note = 'خرج وقتها'; st = ' past out'; }
      }
      html += '<div class="prow' + (k === np.name ? ' next' : st) + (rmd && k === 'maghrib' ? ' rm' : '') + '">' + prIcon(k) +
        '<div class="pmid"><b>' + PR_AR[k] + (rmd && k === 'maghrib' ? ' · الإفطار' : '') + '</b><small>' + note + '</small></div><b class="ptime">' + hm(at) + '</b>' +
        '<i class="pbar"><i style="width:' + pct.toFixed(1) + '%"></i></i></div>';
      prev = at;
      if (k === 'sunrise') html += x.eid ? exRow('eid', 'صلاة العيد', 'تقبّل الله منا ومنكم', x.eid, ' fe' + (x.eid < now ? ' past' : '')) : exRow('duha', 'الضحى', 'بداية وقتها', x.duha, x.duha < now && t.dhuhr <= now ? ' past' : '');
      if (k === 'isha' && x.taraweeh) html += exRow('taraweeh', 'التراويح', 'بعد العشاء', x.taraweeh, ' fe' + (x.taraweeh < now ? ' past' : ''));
    });
    html += exRow('qiyam', 'قيام الليل', 'الثلث الأخير', x.qiyam, '');
    each(eclipsesNear(now, 7), function (e) {
      html += exRow('special', e.title, inDaysText(e.at, now) + ' · ' + e.note + ' · ' + t12(hm(e.at)) + ' – ' + t12(hm(e.end)), e.at, ' sp' + (e.end < now ? ' past' : ''));
    });
    each(specialPrayers(now), function (s) {
      html += exRow('special', esc(s.e.title), (s.in ? 'غداً' : 'اليوم') + (s.e.src === 'g' ? ' · تقويم قوقل' : ''), s.at, ' sp');
    });
    $('pr-list').innerHTML = html;
    $('pr-city').textContent = cfg.city + ' · طريقة أم القرى';
    $('pr-ram').textContent = rmd ? 'رمضان كريم · العشاء بعد المغرب بساعتين (أم القرى)' : '';
  }

  /* ---------- الأذكار ---------- */
  var adSet = 'morning', adIdx = 0;
  function renderAdhkar(auto) {
    if (auto) { adSet = new Date().getHours() < 13 ? 'morning' : 'evening'; adIdx = 0; }
    var list = w.ADHKAR[adSet], a = list[adIdx];
    $('ad-m').className = 'tab' + (adSet === 'morning' ? ' on' : '');
    $('ad-e').className = 'tab' + (adSet === 'evening' ? ' on' : '');
    if (!recMode) stopSpeak();
    /* الآيات تُعرض بنصها العثماني (a.q) وخط حفص، وبقية الأذكار بالخط العادي.
       رقم الآية يُوضع داخل زخرفة ۝ بالـ CSS لأن WebView القديم لا يدمجهما؛ النص نفسه لا يتغير */
    var body = a.q ? (a.qpre ? '<div class="ad-pre">' + esc(a.qpre) + '</div>' : '') + '<div class="quran' + (a.q.length > 300 ? ' long' : '') + '">' +
      esc(a.q).replace(/ ([٠-٩]+)/g, ' <span class="ayah">۝<b>$1</b></span>') + '</div>'
      : '<div class="ad-text' + (a.t.length > 260 ? ' long' : '') + '">' + esc(a.t) + '</div>';
    $('ad-card').innerHTML = '<button class="spk" id="ad-spk" aria-label="استماع"><svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12"/></svg></button>' + body +
      (a.f ? '<div class="ad-fadl">' + esc(a.f) + '</div>' : '') +
      '<div class="ad-meta"><span>' + esc(a.s) + '</span><b id="ad-cnt">' + (a.n > 1 ? '× ' + ar(a.n) : 'مرة واحدة') + '</b></div>';
    if (speaking) setSpk(true);
    $('ad-idx').textContent = ar(adIdx + 1) + ' / ' + ar(list.length);
  }
  /* ---------- قراءة الأذكار بالصوت (سماعة) ---------- */
  var speaking = false;
  function adChunks(t) {
    t = t.replace(/۝/g, "، ").replace(/ﷺ/g, " صلى الله عليه وسلم ").replace(/\n/g, "، ").replace(/\s+/g, " ");
    var parts = t.split(/(?:،|\.)\s*/), out = [], acc = "";
    each(parts, function (p) {
      p = p.replace(/^\s+|\s+$/g, ""); if (!p) return;
      while (p.length > 170) {
        var cut = p.lastIndexOf(" ", 170); if (cut < 40) cut = 170;
        if (acc) { out.push(acc); acc = ""; }
        out.push(p.slice(0, cut)); p = p.slice(cut).replace(/^\s+/, "");
      }
      if (acc && (acc + "، " + p).length > 170) { out.push(acc); acc = p; } else acc = acc ? acc + "، " + p : p;
    });
    if (acc) out.push(acc);
    return out;
  }
  function setSpk(on) { var b = $("ad-spk"); if (b) b.className = "spk" + (on ? " on" : ""); }
  var recMode = false, progTimer = null;
  function fmtMs(ms) { var s = Math.floor(ms / 1000); return pad(Math.floor(s / 60)) + ':' + pad(s % 60); }
  function showProg(on) {
    recMode = on; $('p-adhkar').className = 'page' + (cur === 'adhkar' ? ' active' : '') + (on ? ' rec' : '');
    clearInterval(progTimer);
    if (on) progTimer = setInterval(function () {
      try {
        var a = HF.audioInfo().split(','), pos = +a[0], dur = +a[1];
        $('ad-pfill').style.width = (dur > 0 ? pos / dur * 100 : 0) + '%';
        $('ad-ptime').textContent = fmtMs(pos) + ' / ' + fmtMs(dur);
        $('ad-pp').textContent = a[2] === '1' ? '❚❚' : '▶';
        if (dur > 0) adSync(pos / 1000);
      } catch (e) { }
    }, 500);
  }
  /* مزامنة الأذكار مع التسجيل: لكل ذكر a = [بداية، نهاية] بالثواني في ملف الشيخ، و r = بدايات التكرارات.
     إذا انتقل الشيخ للذكر التالي تنتقل الصفحة معه، والأسهم تنقل التسجيل إلى بداية الذكر المعروض */
  function adAt(sec) {
    var list = w.ADHKAR[adSet], i, best = -1;
    for (i = 0; i < list.length; i++) if (list[i].a && sec >= list[i].a[0] - 0.3) best = i;
    return best;
  }
  var adSeekAt = 0;
  function adSync(sec) {
    if (Date.now() - adSeekAt < 1500) return;
    var i = adAt(sec); if (i < 0) return;
    if (i !== adIdx) { adIdx = i; renderAdhkar(false); }
    var a = w.ADHKAR[adSet][adIdx], c = $('ad-cnt');
    if (c && a.r && a.r.length > 1) { var k = 0; each(a.r, function (t, j) { if (sec >= t - 0.3) k = j; }); c.textContent = ar(k + 1) + ' من ' + ar(a.n); }
  }
  function stopSpeak() { if (!speaking) return; speaking = false; if (HF && HF.stopAudio) HF.stopAudio(); setSpk(false); showProg(false); }
  function speakAdhkar() {
    if (speaking) { stopSpeak(); return; }
    if (!HF || !HF.playSequenceWait) return;
    var rec = adSet === 'morning' ? 'adhkar-morning' : 'adhkar-evening';
    if (HF.hasFile && HF.hasFile(rec)) {
      speaking = true; setSpk(true); showProg(true);
      var it = w.ADHKAR[adSet][adIdx];
      if (HF.playFileAt) HF.playFileAt(rec, it.a ? Math.round(it.a[0] * 1000) : 0);
      else HF.playSequence(JSON.stringify([{ t: 'file', name: rec }]));
      return;
    }
    var items = []; each(adChunks(w.ADHKAR[adSet][adIdx].t), function (c) { items.push({ t: "say", text: c }); });
    speaking = true; setSpk(true); HF.playSequenceWait(JSON.stringify(items));
  }
  w.onSeqDone = function () { speaking = false; setSpk(false); showProg(false); if (tmSaying) { tmSaying = false; tmRing(); } };
  function preloadAdhkar() {
    if (!HF || !HF.ttsEnsure) return;
    var seen2 = {}, list = [];
    each(["morning", "evening"], function (s) { each(w.ADHKAR[s], function (a) { each(adChunks(a.t), function (c) { if (!seen2[c]) { seen2[c] = 1; list.push(c); } }); }); });
    HF.ttsEnsure(JSON.stringify(list));
  }
  function adMove(d) {
    var n = w.ADHKAR[adSet].length; adIdx = (adIdx + d + n) % n; renderAdhkar(false);
    var a = w.ADHKAR[adSet][adIdx];
    if (recMode && a.a && HF && HF.audioSeekMs) adSeekAt = Date.now(), HF.audioSeekMs(Math.round(a.a[0] * 1000));
  }
  /* ---------- الأذكار التلقائية: تسجيل الشيخ يُقرأ كاملاً مرة واحدة في اليوم لكل من الصباح والمساء ----------
     الافتراضي بعد الفجر بـ ٤٠ دقيقة وبعد العصر بـ ٤٠ دقيقة، والأدمن يغيّرها (دقائق بعد الصلاة أو وقت ثابت أو إيقاف).
     إن كانت الأذكار تُقرأ أصلاً تُترك كما هي؛ وإن كان صوت آخر يعمل (نداء صلاة، منبه…) تنتظر حتى ٣٠ دقيقة */
  var adAuto = Store.get('adauto', {});
  function adhAt(s, date) {
    var a = (cfg.adh || {})[s]; if (!a || a.on === false) return null;
    if (a.at && /^\d\d:\d\d$/.test(a.at)) return atTime(date, a.at);
    return new Date(times(date)[s === 'm' ? 'fajr' : 'asr'].getTime() + (a.min >= 0 ? +a.min : 40) * 60000);
  }
  function audioBusy() {
    if (callOpen || soundNow || tmSaying || document.querySelector('#alarmring.show, #tmdone.show, #menu.show')) return true;
    try { return HF && HF.audioInfo && String(HF.audioInfo()).split(',')[2] === '1'; } catch (e) { return false; }
  }
  function tickAdhAuto(now) {
    each(['m', 'e'], function (s) {
      var at = adhAt(s, now), key = s + ymd(now);
      if (!at || now < at || now - at > 30 * 60000 || adAuto[key]) return;
      if (!speaking && audioBusy()) return;
      var keep = {}; keep[key] = 1; for (var k in adAuto) if (k.indexOf(ymd(now)) > 0) keep[k] = 1;
      adAuto = keep; Store.set('adauto', adAuto);
      if (speaking) return;
      var rec = s === 'm' ? 'adhkar-morning' : 'adhkar-evening';
      if (!HF || !HF.hasFile || !HF.hasFile(rec)) return;
      closeAll(); show('adhkar');
      adSet = s === 'm' ? 'morning' : 'evening'; adIdx = 0; renderAdhkar(false);
      speakAdhkar();
    });
  }
  /* نافذة الأدمن: لكل من الصباح والمساء خيار «بعد الصلاة بكذا دقيقة» أو «وقت ثابت» أو «إيقاف» */
  var ADH_MINS = [0, 10, 15, 20, 30, 40, 45, 60, 90, 120];
  function adhWhenText(s) {
    var v = $('ah-' + s + 'w').value, now = new Date(), at;
    if (v === 'off') return 'لن تُقرأ تلقائياً';
    at = v === 'at' ? atTime(now, getTimeFields('ah-' + s + 'h', 'ah-' + s + 'm', 'ah-' + s + 'a')) : new Date(times(now)[s === 'm' ? 'fajr' : 'asr'].getTime() + v * 60000);
    return 'اليوم الساعة ' + t12(hm(at));
  }
  function fillAdhSel(s) {
    var sel = $('ah-' + s + 'w'), a = cfg.adh[s], p = s === 'm' ? 'الفجر' : 'العصر', h = '<option value="off">إيقاف التشغيل التلقائي</option>';
    var mins = ADH_MINS.indexOf(+a.min) < 0 ? ADH_MINS.concat([+a.min]).sort(function (x, y) { return x - y; }) : ADH_MINS;
    each(mins, function (n) { h += '<option value="' + n + '">' + (n ? 'بعد ' + p + ' بـ ' + ar(n) + ' دقيقة' : 'مع أذان ' + p) + (n === 40 ? ' (الافتراضي)' : '') + '</option>'; });
    sel.innerHTML = h + '<option value="at">وقت ثابت أختاره</option>';
    sel.value = a.on === false ? 'off' : a.at ? 'at' : String(a.min);
    if (!sel.value) sel.value = '40';
    setTimeFields('ah-' + s + 'h', 'ah-' + s + 'm', 'ah-' + s + 'a', a.at || (s === 'm' ? '06:00' : '16:30'));
    adhSelChanged(s);
  }
  function adhSelChanged(s) { $('ah-' + s + 't').style.display = $('ah-' + s + 'w').value === 'at' ? '' : 'none'; $('ah-' + s + 'now').textContent = adhWhenText(s); }
  function openAdhEdit() { fillAdhSel('m'); fillAdhSel('e'); $('adhedit').className = 'overlay show'; }
  function setAdh(s, v, at) {
    var a = cfg.adh[s];
    if (v === 'off') a.on = false;
    else if (v === 'at' && /^\d\d:\d\d$/.test(at || '')) { a.on = true; a.at = at; }
    else if (isFinite(v) && +v >= 0 && +v <= 240) { a.on = true; a.at = ''; a.min = +v; }
  }
  function saveAdhEdit() {
    each(['m', 'e'], function (s) { setAdh(s, $('ah-' + s + 'w').value, getTimeFields('ah-' + s + 'h', 'ah-' + s + 'm', 'ah-' + s + 'a')); });
    saveCfg(); publishSoon(); closeAll(); toast('حُفظت أوقات الأذكار');
  }

  /* ---------- التقويم ---------- */
  /* الشهر المعروض يتبع اليوم الحالي: يُعاد ضبطه عند فتح الصفحة وبعد ضبط الساعة (الجهاز يبدأ على ١٩٧٠ بعد إعادة التشغيل)،
     ولا يبقى على شهر آخر تصفّحه المستخدم أكثر من دقيقتين */
  var calY = 0, calM = 0, calAuto = true, calTouched = 0, calDay = '', dayDate = null, dayFromHome = false;
  function calToday() { var n = new Date(); calY = n.getFullYear(); calM = n.getMonth(); calAuto = true; }
  function calStep(d) { calM += d; if (calM > 11) { calM = 0; calY++; } if (calM < 0) { calM = 11; calY--; } calAuto = false; calTouched = Date.now(); renderCal(); }
  calToday();
  var DOW = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  function renderCal() {
    var first = new Date(calY, calM, 1), offset = (first.getDay() + 1) % 7, days = new Date(calY, calM + 1, 0).getDate();
    var rows = Math.ceil((offset + days) / 7), html = '', i, today = ymd(new Date());
    calDay = today;
    $('cal-gm').textContent = L.AR_MONTHS[calM] + ' ' + ar(calY);
    var h1 = L.hijri(first), h2 = L.hijri(new Date(calY, calM, days));
    renderGcalNote();
    $('cal-hm').textContent = L.HMONTHS[h1.m] + ' ' + ar(h1.y) + (h1.m !== h2.m ? ' – ' + L.HMONTHS[h2.m] + ' ' + ar(h2.y) : '');
    each(DOW, function (d) { html += '<div class="cal-dow">' + d + '</div>'; });
    /* داخل كل يوم: أسماء المواعيد وأيام الميلاد (حتى ثلاثة) ثم «+ن» للباقي */
    for (i = 0; i < rows * 7; i++) {
      var dn = i - offset + 1, out = dn < 1 || dn > days, d = new Date(calY, calM, dn);
      var evs = eventsOn(d), chips = '';
      each(evs.slice(0, 3), function (e) { chips += '<span class="chip' + (isBd(e) ? ' b' : '') + '">' + (isBd(e) ? '🎂 ' : '') + esc(e.title) + '</span>'; });
      if (evs.length > 3) chips += '<span class="chip more">+' + ar(evs.length - 3) + '</span>';
      var hd = L.hijri(d), hk = hd.m === 8 ? ' rmd' : (hd.m === 9 && hd.d <= 3) || (hd.m === 11 && hd.d >= 10 && hd.d <= 12) ? ' eidd' : '';
      html += '<div class="cal-cell' + (out ? ' out' : '') + (ymd(d) === today ? ' today' : '') + hk + '" data-d="' + ymd(d) + '"><div>' +
        '<span class="g">' + ar(d.getDate()) + '</span><span class="h">' + ar(hd.d) + '</span><div class="chips2">' + chips + '</div></div></div>';
    }
    $('cal-grid').className = 'cal-grid r' + rows;
    $('cal-grid').innerHTML = html;
  }
  /* ---------- مزامنة تقويم قوقل (رابط iCal السري) ---------- */
  var gcalBusy = false;
  function icsUrl() { var u = HF && HF.getConfig ? String(HF.getConfig('ics') || '') : ''; return u.replace(/^webcal:\/\//i, 'https://'); }
  function renderGcalNote() {
    var n = $('cal-gs'); if (!n) return;
    if (!icsUrl()) { n.textContent = ''; return; }
    n.textContent = gcal.err ? 'تقويم قوقل — خطأ الشبكة' + (gcal.ts ? ' (آخر مزامنة ' + t12(hm(new Date(gcal.ts))) + ')' : '') : gcal.ts ? 'تقويم قوقل · آخر مزامنة ' + t12(hm(new Date(gcal.ts))) : 'تقويم قوقل · جارٍ الجلب…';
  }
  function gcalSync(force) {
    var url = icsUrl();
    if (!url) { if (gEvents.length || gcal.ts) { gEvents = []; gcal = {}; Store.set('gcal', null); renderAll(); lanSoon(); } return; }
    if (gcalBusy || (w.clockOk && !w.clockOk())) return;
    if (!force && gcal.ts && Date.now() - gcal.ts < 29 * 60000 && !gcal.err) return;
    gcalBusy = true;
    httpGet(url, function (ok, body) {
      gcalBusy = false;
      if (ok && String(body).indexOf('BEGIN:VCALENDAR') >= 0 && w.ICal) {
        var now = new Date();
        gEvents = w.ICal.expand(body, new Date(now.getFullYear(), now.getMonth(), now.getDate() - 62), new Date(now.getFullYear(), now.getMonth(), now.getDate() + 400));
        gcal = { ts: Date.now(), n: gEvents.length, err: '', items: gEvents };
        Store.set('gcal', gcal); ensureTts();
      } else { gcal.err = ok ? 'format' : 'net'; }
      renderAll(); if (cur === 'bdays') renderBdays(); lanSoon();
    });
  }
  w.onIcsChanged = function () { gcal = {}; gEvents = []; Store.set('gcal', null); gcalSync(true); toast(icsUrl() ? 'جارٍ ربط تقويم قوقل…' : 'أُلغي ربط تقويم قوقل'); renderAll(); };
  function openDay(date) {
    dayDate = date;
    $('day-title').textContent = dateText(date) + ' · ' + ar(L.hijri(date).d) + ' ' + L.HMONTHS[L.hijri(date).m];
    var html = '';
    each(eventsOn(date), function (e) {
      html += '<div class="evrow' + (isBd(e) ? ' b' : '') + '"><span class="what">' + (isBd(e) ? '🎂 يوم ميلاد ' : '') + esc(e.title) +
        (isBd(e) && bdYearKnown(e) ? ' (يتم ' + yearsText(ageOf(e, date)) + ')' : '') + (e.time ? ' · ' + t12(e.time) : '') +
        '</span>' + (e.src === 'g' ? '<span class="gtag">تقويم قوقل</span>' : '<button class="del" data-id="' + e.id + '">حذف</button>') + '</div>';
    });
    $('day-list').innerHTML = html || '<div class="empty">لا توجد مواعيد في هذا اليوم</div>';
    $('f-title').value = ''; $('f-date').value = ymd(date); setTimeFields('f-th', 'f-tm', 'f-tap', ''); $('f-rep').value = 'none';
    $('day').className = 'overlay show';
  }
  function newId() { return 'e' + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36); }
  function addEvent(ev) {
    for (var i = 0; i < events.length; i++) if (events[i].id === ev.id) { events[i] = ev; saveEvents(); return; }
    events.push(ev); saveEvents();
  }
  function delEvent(id) { events = events.filter(function (e) { return e.id !== id; }); saveEvents(); }

  /* ---------- قائمة المواعيد ---------- */
  function renderEvents() {
    var up = upcoming(120, 10, isAppt), html = '';
    each(up, function (u) {
      var e = u.e;
      html += '<div class="evrow"><span class="when">' + dateText(u.date) + '</span><span class="what">' + esc(e.title) +
        (e.time ? ' · ' + t12(e.time) : '') + '</span><span class="in">' + whenText(u.in) + '</span></div>';
    });
    $('ev-list').innerHTML = html || '<div class="empty">لا توجد مواعيد قادمة — أضفها من «+ موعد» أو من الجوال</div>';
  }

  /* ---------- أيام الميلاد ---------- */
  var BD_EMO = ['🎂', '🎈', '🎁', '🌟', '🦋', '⚽', '🌸', '👑'];
  function yearsText(n) { return n === 1 ? 'سنة' : n === 2 ? 'سنتين' : ar(n) + (n >= 3 && n <= 10 ? ' سنوات' : ' سنة'); }
  function daysText(n) { return n === 1 ? 'يوم' : n === 2 ? 'يومين' : ar(n) + (n >= 3 && n <= 10 ? ' أيام' : ' يوماً'); }
  function nextBd(e) {
    var b = L.parseYmd(e.date), now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var nx = new Date(t0.getFullYear(), b.getMonth(), b.getDate());
    if (nx < t0) nx = new Date(t0.getFullYear() + 1, b.getMonth(), b.getDate());
    return { date: nx, days: Math.round((nx - t0) / 86400000), age: bdYearKnown(e) ? nx.getFullYear() - b.getFullYear() : 0 };
  }
  function bdList() {
    var out = [];
    each(allEvents(), function (e) { if (isBd(e)) { var n = nextBd(e); out.push({ e: e, date: n.date, days: n.days, age: n.age }); } });
    out.sort(function (a, b) { return a.days - b.days; });
    return out;
  }
  function renderBdays() {
    var list = bdList(), hero = '', html = '';
    each(list, function (x, i) {
      var e = x.e, emo = e.emoji || '🎂', when = ar(x.date.getDate()) + ' ' + L.AR_MONTHS[x.date.getMonth()];
      if (x.days === 0) {
        hero += '<div class="bdhero" data-id="' + e.id + '"><div class="confetti"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>' +
          '<div class="bdbig">' + emo + '</div><div><div class="lbl">اليوم يوم ميلاد</div><div class="bdhname">' + esc(e.title) + '</div>' +
          (x.age ? '<div class="mid">يتم ' + yearsText(x.age) + ' 🎉</div>' : '<div class="mid">كل عام وأنت بخير 🎉</div>') + '</div></div>';
        return;
      }
      html += '<div class="bdcard bc' + (i % 4) + '" data-id="' + e.id + '"><div class="bdtop"><span class="bdemo">' + emo + '</span><span class="bdleft"><b>' + (x.days === 1 ? 'غداً' : ar(x.days)) + '</b>' +
        (x.days === 1 ? '' : '<small>' + (x.days >= 3 && x.days <= 10 ? 'أيام' : 'يوماً') + '</small>') + '</span></div>' +
        '<div class="bdname">' + esc(e.title) + '</div><div class="bdwhen">' + L.AR_DAYS[x.date.getDay()] + ' ' + when + (x.age ? ' · يتم ' + yearsText(x.age) : '') + '</div></div>';
    });
    $('bd-hero').innerHTML = hero;
    $('bd-list').innerHTML = html || (hero ? '' : '<div class="empty">لا توجد أيام ميلاد بعد — أضفها من «+ يوم ميلاد» أو من الجوال</div>');
  }
  var bdEmo = '🎂';
  function openBdForm(date) {
    var d = date || new Date();
    $('bd-name').value = ''; $('bd-d').value = String(d.getDate()); $('bd-m').value = String(d.getMonth()); $('bd-y').value = date ? String(d.getFullYear()) : '';
    bdEmo = '🎂'; renderEmo();
    $('bdform').className = 'overlay show';
  }
  function renderEmo() { var h = ''; each(BD_EMO, function (m) { h += '<button data-e="' + m + '"' + (m === bdEmo ? ' class="on"' : '') + '>' + m + '</button>'; }); $('bd-emo').innerHTML = h; }
  function saveBdForm() {
    var name = $('bd-name').value.replace(/^\s+|\s+$/g, ''); if (!name) { toast('اكتب الاسم أولاً'); return; }
    var y = $('bd-y').value || '1900', m = +$('bd-m').value + 1, day = +$('bd-d').value;
    addEvent({ id: newId(), title: name.substr(0, 30), date: y + '-' + pad(m) + '-' + pad(day), time: '', repeat: 'yearly', kind: 'birthday', emoji: bdEmo });
    if (HF && HF.hideKeyboard) HF.hideKeyboard();
    closeAll(); renderAll(); toast('تمت إضافة يوم ميلاد ' + name);
  }
  var bdInfoId = null;
  function openBdInfo(id) {
    var x = null; each(bdList(), function (b) { if (b.e.id === id) x = b; }); if (!x) return;
    bdInfoId = id;
    var b = L.parseYmd(x.e.date);
    $('bi-emo').textContent = x.e.emoji || '🎂'; $('bi-name').textContent = x.e.title;
    $('bi-sub').textContent = ar(b.getDate()) + ' ' + L.AR_MONTHS[b.getMonth()] + (bdYearKnown(x.e) ? ' ' + ar(b.getFullYear()) : '') +
      (x.days === 0 ? ' · اليوم 🎉' : ' · بعد ' + daysText(x.days)) + (x.age ? ' · يتم ' + yearsText(x.age) : '');
    $('bi-del').className = 'btn danger'; $('bi-del').textContent = 'حذف'; $('bi-del').style.display = x.e.src === 'g' ? 'none' : '';
    $('bdinfo').className = 'overlay show';
  }
  function fillBdSelects() {
    var i, o, y = new Date().getFullYear();
    for (i = 1; i <= 31; i++) { o = document.createElement('option'); o.value = i; o.textContent = ar(i); $('bd-d').appendChild(o); }
    for (i = 0; i < 12; i++) { o = document.createElement('option'); o.value = i; o.textContent = L.AR_MONTHS[i]; $('bd-m').appendChild(o); }
    o = document.createElement('option'); o.value = ''; o.textContent = 'بدون سنة'; $('bd-y').appendChild(o);
    for (i = y; i >= 1930; i--) { o = document.createElement('option'); o.value = i; o.textContent = ar(i); $('bd-y').appendChild(o); }
  }

  /* ---------- سجل الأبناء: كل صح = {k: الابن، p: الصلاة أو 't:'+رقم المهمة، d: اليوم} ---------- */
  function recFind(k, p, d) { for (var i = 0; i < records.length; i++) { var r = records[i]; if (r.k === k && r.p === p && r.d === d) return i; } return -1; }
  /* فهرس سريع للسجل (يكبر مع الأشهر)، يُبنى من جديد بعد كل تغيير */
  var recMap = null;
  function recHas(k, p, d) {
    if (!recMap) { recMap = {}; each(records, function (r) { recMap[r.k + '|' + r.p + '|' + r.d] = 1; }); }
    return !!recMap[k + '|' + p + '|' + d];
  }
  function isPr(p) { return PR.indexOf(p) >= 0; }
  function prCount(k, mk) { var n = 0; each(records, function (r) { if (r.k === k && isPr(r.p) && r.d.substr(0, 7) === mk) n++; }); return n; }
  /* عناصر يوم الابن: الصلوات الخمس + مهامه في ذلك اليوم (مهمة بلا أبناء محددين = للجميع)، مرتبة بالوقت.
     المهمة تُحتسب من يوم إضافتها (from) حتى لا تنزل نسبة أيام سابقة */
  function taskFor(t, kid) { return !t.kids || !t.kids.length || t.kids.indexOf(kid) >= 0; }
  function kidItems(kid, date) {
    var t = times(date), d = ymd(date), out = [];
    each(PR, function (p) { out.push({ key: p, name: PR_AR[p], at: t[p], pr: true }); });
    each(tasks, function (x) {
      if (!taskOn(x, date) || !taskFor(x, kid) || (x.from && x.from > d)) return;
      var at = atTime(date, x.time);
      out.push({ key: 't:' + x.id, name: x.name, at: at, end: x.dur ? new Date(at.getTime() + x.dur * 60000) : null });
    });
    out.sort(function (a, b) { return a.at - b.at; });
    return out;
  }
  /* النسبة = ما عليه صح ÷ ما حلّ وقته حتى الآن؛ فإذا دخل وقت صلاة جديدة تنزل النسبة حتى يضع الابن صح. pct = -1 إذا لم يحن شيء بعد */
  /* بداية التقرير لكل ابن: أول يوم سجّل فيه شيئاً، أو يوم إضافته/يوم هذا التحديث — الأيام قبلها لا تُحتسب صفراً */
  var kidFirst = null;
  function kidStart(kid) {
    if (!kidFirst) { kidFirst = {}; each(records, function (r) { if (!kidFirst[r.k] || r.d < kidFirst[r.k]) kidFirst[r.k] = r.d; }); }
    var k = null; each(cfg.kids, function (x) { if (x.id === kid) k = x; });
    var s = (k && k.since) || cfg.repFrom || '2000-01-01', f = kidFirst[kid];
    return f && f < s ? f : s;
  }
  function kidScore(kid, date, now) {
    var d = ymd(date), s = { due: 0, done: 0, pn: 0, pd: 0, tn: 0, td: 0, pct: -1 };
    if (d < kidStart(kid)) return s;
    each(kidItems(kid, date), function (it) {
      if (it.at > now) return;
      var ok = recHas(kid, it.key, d);
      s.due++; if (ok) s.done++;
      if (it.pr) { s.pn++; if (ok) s.pd++; } else { s.tn++; if (ok) s.td++; }
    });
    s.pct = s.due ? Math.round(s.done / s.due * 100) : -1;
    return s;
  }
  function weekScore(kid, now) {
    var due = 0, done = 0, i;
    for (i = 0; i < 7; i++) { var s = kidScore(kid, dayOff(now, -i), now); due += s.due; done += s.done; }
    return due ? Math.round(done / due * 100) : -1;
  }
  function pctText(p) { return p < 0 ? '—' : p + '%'; }
  function pctLevel(p) { return p < 0 ? 'lv0' : p >= 80 ? 'lv3' : p >= 50 ? 'lv2' : 'lv1'; }
  function withSince(list) {
    var old = {}, d = ymd(new Date()); each(cfg.kids, function (k) { old[k.id] = k.since; });
    return list.map(function (k) { k.since = old[k.id] || (old.hasOwnProperty(k.id) ? '' : d); if (!k.since) delete k.since; return k; });
  }
  function kidName(id) { var n = ''; each(cfg.kids, function (k) { if (k.id === id) n = k.name; }); return n; }
  /* ---------- بطل الشهر: أكثر ابن سجّل صلواته في الشهر الميلادي، والجائزة يحددها الأدمن من الجوال ---------- */
  function monthKey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1); }
  /* الترتيب: [{id, name, n}] من الأكثر صلاةً؛ win = الأبطال (أكثر من واحد عند التعادل) */
  function champOf(d) {
    var mk = monthKey(d), list = [];
    each(cfg.kids, function (k) { list.push({ id: k.id, name: k.name, n: prCount(k.id, mk) }); });
    list.sort(function (a, b) { return b.n - a.n; });
    var top = list.length ? list[0].n : 0;
    return { m: L.AR_MONTHS[d.getMonth()], list: list, top: top, win: top > 0 ? list.filter(function (x) { return x.n === top; }) : [] };
  }
  function namesJoin(arr) { return arr.map(function (x) { return x.name; }).join(' و'); }
  function renderChamp() {
    var now = new Date(), c = champOf(now), html;
    /* أول أسبوع من الشهر: يُعلن بطل الشهر الماضي */
    var prev = now.getDate() <= 7 ? champOf(new Date(now.getFullYear(), now.getMonth() - 1, 1)) : null;
    if (prev && prev.win.length) {
      html = '<div class="ch-ic">🏆</div><div class="ch-tx"><small>بطل شهر ' + prev.m + '</small><b>' + esc(namesJoin(prev.win)) + ' 🎉</b>' +
        '<span>' + ar(prev.top) + ' صلاة' + (cfg.prize ? ' · 🎁 الجائزة: ' + esc(cfg.prize) : '') + '</span></div>';
    } else if (c.win.length) {
      html = '<div class="ch-ic">🏆</div><div class="ch-tx"><small>بطل شهر ' + c.m + ' حتى الآن</small><b>' + esc(namesJoin(c.win)) + (c.win.length > 1 ? ' (تعادل)' : '') + '</b>' +
        '<span>' + ar(c.top) + ' صلاة' + (cfg.prize ? ' · 🎁 الجائزة: ' + esc(cfg.prize) : '') + '</span></div>';
    } else {
      html = '<div class="ch-ic">🏆</div><div class="ch-tx"><small>بطل شهر ' + c.m + '</small><b>من يكون البطل؟</b><span>سجّلوا صلواتكم كل يوم' + (cfg.prize ? ' · 🎁 الجائزة: ' + esc(cfg.prize) : '') + '</span></div>';
    }
    $('champ').innerHTML = html;
  }
  /* ---------- صفحة الأبناء = التقرير: نسبة إنجاز اليوم، الصلوات والمهام، الأسبوع، صلوات الشهر، وأعمدة آخر ٧ أيام ---------- */
  var DSHORT = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
  function frac(a, b) { return ar(a) + ' / ' + ar(b); }
  function renderKids() {
    renderChamp();
    var now = new Date(), html = '', mk = monthKey(now), c = champOf(now), today = ymd(now);
    each(cfg.kids, function (kid, idx) {
      var s = kidScore(kid.id, now, now), wk = weekScore(kid.id, now), lead = c.win.some(function (x) { return x.id === kid.id; });
      var left = kidItems(kid.id, now).filter(function (it) { return it.at <= now && !recHas(kid.id, it.key, today); }).map(function (it) { return it.name; });
      var msg = s.pct < 0 ? 'لم يحن وقت أي مهمة اليوم بعد' : left.length ? 'باقي: ' + left.join('، ') : 'أنجز كل ما حلّ وقته 🌟';
      var bars = '', i;
      for (i = 6; i >= 0; i--) {
        var d = dayOff(now, -i), p = kidScore(kid.id, d, now).pct;
        bars += '<div class="wd' + (i ? '' : ' td') + '"><b>' + (p < 0 ? '' : p + '%') + '</b><div class="wb"><i class="' + pctLevel(p) + '" style="height:' + Math.max(p, 3) + '%"></i></div><span>' + DSHORT[d.getDay()] + '</span></div>';
      }
      html += '<div class="kid c' + (idx % 4) + '"><div class="nm"><span>' + (lead ? '👑 ' : '') + esc(kid.name) + '</span><button class="repbtn" data-rep="' + kid.id + '">التقرير المفصّل</button></div>' +
        '<div class="kp"><small>نسبة إنجاز المهام اليوم</small><b class="' + pctLevel(s.pct) + '">' + pctText(s.pct) + '</b></div>' +
        '<div class="bar kbar"><i class="' + pctLevel(s.pct) + '" style="width:' + Math.max(s.pct, 0) + '%"></i></div>' +
        '<div class="kmsg">' + esc(msg) + '</div>' +
        '<div class="kst"><div><small>الصلوات</small><b>' + frac(s.pd, s.pn) + '</b></div><div><small>المهام</small><b>' + (s.tn ? frac(s.td, s.tn) : '—') + '</b></div>' +
        '<div><small>آخر ٧ أيام</small><b>' + pctText(wk) + '</b></div><div><small>هذا الشهر</small><b>⭐ ' + ar(prCount(kid.id, mk)) + '</b></div></div>' +
        '<div class="kweek">' + bars + '</div></div>';
    });
    $('kids-wrap').className = 'kids-wrap' + (cfg.kids.length > 3 ? ' many' : cfg.kids.length === 3 ? ' k3' : '');
    $('kids-wrap').innerHTML = html || '<div class="empty">أضف الأبناء من القائمة المخفية أو من الجوال</div>';
  }

  /* ---------- إدارة الأبناء (من القائمة المخفية) ---------- */
  function keRow(id, name) {
    return '<div class="kerow" data-id="' + esc(id) + '"><input type="text" maxlength="20" placeholder="اسم الابن" value="' + esc(name) + '"><button class="del">حذف</button></div>';
  }
  function openKidsEdit() {
    var html = '';
    each(cfg.kids, function (k) { html += keRow(k.id, k.name); });
    $('ke-list').innerHTML = html;
    $('kidsedit').className = 'overlay show';
  }
  function saveKidsEdit() {
    var kids = [];
    each($('ke-list').querySelectorAll('.kerow'), function (r) {
      var n = r.getElementsByTagName('input')[0].value.replace(/^\s+|\s+$/g, '');
      if (n) kids.push({ id: r.getAttribute('data-id'), name: n.substr(0, 20) });
    });
    if (!kids.length) return;
    cfg.kids = withSince(kids); saveCfg(); publishSoon(); ensureTts();
    closeAll(); renderKids();
  }
  function toggleRecord(k, p, d) {
    if (!k || !p) return;
    var i = recFind(k, p, d);
    if (i >= 0) records.splice(i, 1);
    else {
      records.push({ k: k, p: p, d: d });
      each(cfg.kids, function (kd) { if (kd.id === k) praise(kd); });
    }
    saveRecords(); lanSoon();
    if (cur === 'kids') renderKids();
    if (cur === 'tasks') renderTasks();
  }
  /* تعديل الأدمن (القائمة المخفية أو الجوال): مثلاً صلاة الأمس نسي الابن تسجيلها، أو كنتم خارج البيت. بلا عبارة «بارك الله فيك» */
  function setRecord(k, p, d, on) {
    if (!kidName(k) || !p || !/^\d{4}-\d\d-\d\d$/.test(d)) return;
    var i = recFind(k, p, d);
    if (on && i < 0) records.push({ k: k, p: p, d: d });
    if (!on && i >= 0) records.splice(i, 1);
    saveRecords(); lanSoon();
    if (cur === 'kids') renderKids();
    if (cur === 'tasks') renderTasks();
  }
  /* جدول التقرير لأيام متتالية تنتهي بـ end: صف لكل صلاة ومهمة ظهرت فيها.
     الخانة: 2 = صح، 1 = حلّ وقتها بلا صح، 0 = لم يحن وقتها، -1 = لا تخصه ذلك اليوم */
  function reportGrid(kid, end, n, all) {
    var now = new Date(), days = [], rows = [], idx = {}, i, st = all ? '' : kidStart(kid);
    for (i = n - 1; i >= 0; i--) days.push(dayOff(end, -i));
    each(days, function (d, j) {
      each(kidItems(kid, d), function (it) {
        if (idx[it.key] === undefined) { idx[it.key] = rows.length; rows.push({ p: it.key, n: it.name, pr: !!it.pr, tm: it.at.getHours() * 60 + it.at.getMinutes(), c: [] }); }
        rows[idx[it.key]].c[j] = recHas(kid, it.key, ymd(d)) ? 2 : ymd(d) < st ? -1 : it.at > now ? 0 : 1;
      });
    });
    each(rows, function (r) { for (var j = 0; j < n; j++) if (r.c[j] === undefined) r.c[j] = -1; });
    rows.sort(function (a, b) { return a.tm - b.tm; });
    return { days: days, rows: rows, pct: days.map(function (d) { return kidScore(kid, d, now).pct; }) };
  }
  var repKid = '', repEnd = null, repEdit = false;
  function openReport(kid, edit) {
    repKid = kid || (cfg.kids[0] || {}).id; repEdit = !!edit; repEnd = new Date();
    if (!repKid) return;
    renderReport(); $('report').className = 'overlay show';
  }
  function renderReport() {
    var g = reportGrid(repKid, repEnd, 7, repEdit), now = new Date(), html = '<table><tr><th></th>', due = 0, done = 0;
    $('rep-title').textContent = (repEdit ? 'تعديل تقرير ' : 'تقرير ') + kidName(repKid);
    $('rep-kids').innerHTML = repEdit ? cfg.kids.map(function (k) { return '<button data-rk="' + k.id + '"' + (k.id === repKid ? ' class="on"' : '') + '>' + esc(k.name) + '</button>'; }).join('') : '';
    $('rep-kids').style.display = repEdit ? '' : 'none';
    $('rep-help').style.display = repEdit ? '' : 'none';
    $('rep-range').textContent = ar(g.days[0].getDate()) + ' ' + L.AR_MONTHS[g.days[0].getMonth()] + ' – ' + ar(g.days[6].getDate()) + ' ' + L.AR_MONTHS[g.days[6].getMonth()];
    $('rep-next').disabled = ymd(repEnd) >= ymd(now);
    each(g.days, function (d) { html += '<th' + (ymd(d) === ymd(now) ? ' class="td"' : '') + '>' + DSHORT[d.getDay()] + '<br>' + ar(d.getDate()) + '</th>'; });
    html += '</tr>';
    each(g.rows, function (r) {
      html += '<tr><th>' + esc(r.n) + '</th>';
      each(r.c, function (c, j) {
        var mark = c === 2 ? (r.pr ? '⭐' : '✓') : c === 1 ? '✕' : c === 0 ? '·' : '';
        if (c >= 1) { due++; if (c === 2) done++; }
        html += '<td class="s' + (c + 1) + (repEdit && c >= 0 ? ' ed' : '') + '"' + (repEdit && c >= 0 ? ' data-p="' + esc(r.p) + '" data-d="' + ymd(g.days[j]) + '"' : '') + '>' + mark + '</td>';
      });
      html += '</tr>';
    });
    html += '<tr class="pctrow"><th>النسبة</th>';
    each(g.pct, function (p) { html += '<td class="' + pctLevel(p) + '">' + (p < 0 ? '' : p + '%') + '</td>'; });
    html += '</tr></table><h3>إنجاز هذه الأيام: ' + (due ? Math.round(done / due * 100) + '% (' + ar(done) + ' من ' + ar(due) + ')' : '—') + '</h3>';
    $('rep-body').innerHTML = html;
  }

  /* ---------- نداء الصلاة ---------- */
  var callOpen = false, callKey = '', calls = Store.get('calls', {});
  function showCall(name, mode, key) {
    callOpen = true; callKey = key || '';
    $('call-lbl').textContent = mode === 'pre' ? 'اقترب موعد الصلاة' : 'حان وقت الصلاة';
    $('call-name').textContent = PR_AR[name];
    $('call-sub').textContent = hm(times(new Date())[name]);
    var html = '', today = ymd(new Date());
    each(cfg.kids, function (kid, idx) {
      var on = recFind(kid.id, name, today) >= 0;
      html += '<button class="btn kid' + (idx % 4) + '" data-k="' + kid.id + '" data-p="' + name + '">' + (on ? '⭐ ' : '') + esc(kid.name) + ' صلّى</button>';
    });
    $('call-kids').innerHTML = html;
    $('call').className = 'overlay show';
  }
  function hideCall() { callOpen = false; $('call').className = 'overlay'; if (HF && HF.stopAudio) HF.stopAudio(); }
  function tickCalls(now) {
    var t = times(now), changed = false;
    each(PR, function (n) {
      var diff = t[n] - now, key = ymd(now) + n;
      if (diff > 0 && diff <= 180000 && !calls['pre' + key]) { calls['pre' + key] = 1; changed = true; showCall(n, 'pre', key); }
      if (diff <= 0 && diff > -90000 && !calls['now' + key]) { calls['now' + key] = 1; changed = true; showCall(n, 'now', key); playPrayerCall(n); }
      if (callOpen && callKey === key && diff < -40 * 60000) hideCall();
    });
    if (changed) {
      var keep = {}, y = ymd(now);
      for (var k in calls) if (k.indexOf(y) >= 0) keep[k] = 1;
      calls = keep; Store.set('calls', calls);
    }
  }

  /* ---------- الصوت ---------- */
  var actx = null, chimeTimer = null;
  function chime() {
    try {
      var AC = w.AudioContext || w.webkitAudioContext; if (!AC) return;
      actx = actx || new AC();
      var notes = [523.25, 659.25, 783.99, 1046.5, 783.99, 659.25, 523.25], i;
      for (i = 0; i < notes.length; i++) {
        (function (f, at) {
          var o = actx.createOscillator(), g = actx.createGain();
          o.type = 'sine'; o.frequency.value = f; o.connect(g); g.connect(actx.destination);
          var t0 = actx.currentTime + at;
          g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.4, t0 + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.9);
          o.start(t0); o.stop(t0 + 1);
        })(notes[i], i * 0.8);
      }
    } catch (e) { }
  }
  /* نداء الأطفال بالاسم: «محمد، صلاة المغرب» ثم الأذان إن وُجد ملفه */
  var praiseTimer = null;
  function praiseText(kid) { return 'بارك الله فيك يا ' + kid.name; }
  function praise(kid) {
    var b = $('praise'); b.textContent = praiseText(kid) + ' ⭐'; b.className = 'show';
    clearTimeout(praiseTimer); praiseTimer = setTimeout(function () { b.className = ''; }, 4500);
  }
  function sayText(kid, p) { return nameSpoken(kid.name) + '، صَلَاةُ ' + PR_SPOKEN[p]; }
  /* الأذان كتذكير صوتي: «حان الآن وقت صلاة …» ثم نداء الأبناء بأسمائهم */
  function announceText(p) { return 'حَانَ الْآنَ وَقْتُ صَلَاةِ ' + PR_SPOKEN[p]; }
  function playPrayerCall(p) {
    if (HF && HF.playSequenceWait) {
      var items = [{ t: 'say', text: announceText(p) }];
      each(cfg.kids, function (k) { items.push({ t: 'say', text: sayText(k, p) }); });
      items.push({ t: 'adhan' });
      HF.playSequenceWait(JSON.stringify(items));
    } else { chime(); }
    clearTimeout(chimeTimer);
    chimeTimer = setTimeout(function () { if (HF && HF.stopAudio) HF.stopAudio(); }, 6 * 60000);
  }
  /* تحميل أصوات الأسماء مسبقاً (مرة واحدة لكل اسم) لتعمل بلا إنترنت وقت الأذان */
  var ttsTimer = null;
  function ensureTts() {
    if (!HF || !HF.ttsEnsure) return;
    clearTimeout(ttsTimer);
    ttsTimer = setTimeout(function () {
      var texts = [];
      each(PR, function (p) { texts.push(announceText(p)); });
      each(cfg.kids, function (k) { each(PR, function (p) { texts.push(sayText(k, p)); }); });
      each(upcoming(7, 15), function (u) { if (u.e.time) { texts.push(evSay('pre', u.e)); texts.push(evSay('now', u.e)); } else texts.push(evSay('day', u.e)); });
      each(TM_NAMES, function (n) { texts.push(tmSay(n[0])); });
      each(tasks, function (t) { texts.push(taskSay(t)); if (t.dur) texts.push(taskEndSay(t)); });
      HF.ttsEnsure(JSON.stringify(texts));
    }, 2500);
  }
  /* ---------- المنبه ---------- */
  var alarms = Store.get("alarms", []);
  var alRingTimer = null, alCurrent = null, alSnooze = null, alBeepTimer = null, alEditId = null;
  var AL_ORDER = [6, 0, 1, 2, 3, 4, 5];
  function saveAlarms() { Store.set("alarms", alarms); publishSoon(); }
  function alDaysText(a) {
    if (!a.days || !a.days.length) return "مرة واحدة";
    if (a.days.length === 7) return "كل يوم";
    var s = []; each(AL_ORDER, function (d) { if (a.days.indexOf(d) >= 0) s.push(L.AR_DAYS[d]); });
    return s.join("، ");
  }
  function renderAlarms() {
    var html = "";
    each(alarms, function (a) {
      html += '<div class="alrow' + (a.on ? "" : " off") + '" data-id="' + a.id + '"><div class="altime">' + t12(a.time, true) + '</div><div class="alinfo"><b>' + esc(a.label || "منبه") + "</b><span>" + alDaysText(a) + '</span></div><button class="altog' + (a.on ? " on" : "") + '" data-tog="' + a.id + '"><i></i></button></div>';
    });
    $("al-list").innerHTML = html || '<div class="empty">لا توجد منبهات. اضغط «+ منبه جديد»</div>';
  }
  function openAlarmEdit(id) {
    alEditId = id || null; var a = null; each(alarms, function (x) { if (x.id === id) a = x; });
    setTimeFields("al-th", "al-tm", "al-tap", a ? a.time : "07:00");
    $("al-label").value = a ? a.label : "";
    var days = a ? a.days : [];
    each(document.querySelectorAll("#al-days button"), function (b) { b.className = days.indexOf(+b.getAttribute("data-d")) >= 0 ? "on" : ""; });
    $("al-del").style.display = a ? "" : "none";
    $("alarmedit").className = "overlay show";
  }
  function saveAlarmEdit() {
    var t = getTimeFields("al-th", "al-tm", "al-tap"); if (!t) return;
    var days = []; each(document.querySelectorAll("#al-days button.on"), function (b) { days.push(+b.getAttribute("data-d")); });
    var a = null; each(alarms, function (x) { if (x.id === alEditId) a = x; });
    if (!a) { a = { id: "a" + Date.now().toString(36) }; alarms.push(a); }
    a.time = t; a.label = $("al-label").value.replace(/^\s+|\s+$/g, "").substr(0, 30); a.days = days; a.on = true; a.last = "";
    saveAlarms(); closeAll(); renderAlarms();
  }
  function ringAlarm(a) {
    alCurrent = a; $("ar-time").textContent = hm(new Date()); $("ar-label").textContent = a.label || "المنبه";
    $("alarmring").className = "overlay show";
    if (HF && HF.alarmStart) HF.alarmStart(); else { chime(); clearInterval(alBeepTimer); alBeepTimer = setInterval(chime, 7000); }
    clearTimeout(alRingTimer); alRingTimer = setTimeout(stopAlarm, 3 * 60000);
  }
  function stopAlarm() {
    closeLog('stopAlarm');
    clearTimeout(alRingTimer); clearInterval(alBeepTimer);
    $("alarmring").className = "overlay";
    if (HF && HF.alarmStop) HF.alarmStop();
    alCurrent = null;
  }
  function snoozeAlarm() { var a = alCurrent; stopAlarm(); if (a) alSnooze = { at: Date.now() + 5 * 60000, a: a }; }
  function tickAlarms(now) {
    if (alSnooze && Date.now() >= alSnooze.at) { var s = alSnooze.a; alSnooze = null; ringAlarm(s); return; }
    var key = ymd(now) + hm(now);
    each(alarms, function (a) {
      if (!a.on || a.time !== hm(now) || a.last === key) return;
      if (a.days && a.days.length && a.days.indexOf(now.getDay()) < 0) return;
      a.last = key;
      if (!a.days || !a.days.length) a.on = false;
      saveAlarms(); if (cur === "alarm") renderAlarms();
      ringAlarm(a);
    });
  }
  /* ---------- المنبه / المؤقت / ساعة الإيقاف (أقسام صفحة المنبه) ---------- */
  var alSeg = 'alarm';
  function setSeg(s) {
    alSeg = s;
    each(document.querySelectorAll('#al-seg button'), function (b) { b.className = b.getAttribute('data-s') === s ? 'on' : ''; });
    each(['alarm', 'timer', 'sw'], function (k) { $('pane-' + k).style.display = k === s ? '' : 'none'; });
    renderTimer(); renderSw(); updatePill();
  }
  function fmtDur(ms, cs) {
    var t = Math.max(0, ms), h = Math.floor(t / 3600000), m = Math.floor(t % 3600000 / 60000), s = Math.floor(t % 60000 / 1000);
    return (h ? h + ':' : '') + pad(m) + ':' + pad(s) + (cs ? '.' + pad(Math.floor(t % 1000 / 10)) : '');
  }

  /* المؤقت: يُحفظ وقت الانتهاء فيستمر بعد إعادة التحميل. الحلقة الملوّنة تتدرج من الأخضر إلى الأحمر */
  var TM_NAMES = [['', 'بدون اسم', ''], ['المذاكرة', 'مذاكرة', 'الْمُذَاكَرَة'], ['اللعب', 'لعب', 'اللَّعِب'], ['النوم', 'نوم', 'النَّوْم'],
    ['الطبخ', 'طبخ', 'الطَّبْخ'], ['الرياضة', 'رياضة', 'الرِّيَاضَة'], ['الشاشة', 'الشاشة', 'الشَّاشَة']];
  var TM_PRE = [[60, '١ د'], [300, '٥ د'], [600, '١٠ د'], [900, '١٥ د'], [1800, '٣٠ د'], [3600, 'ساعة']];
  var tm = Store.get('timer', null), tmSet = { h: 0, m: 5, s: 0 }, tmName = '', tmSaying = false, tmRingTimer = null;
  function tmSay(name) {
    var sp = ''; each(TM_NAMES, function (n) { if (n[0] === name) sp = n[2]; }); each(TK_NAMES, function (n) { if (n[0] === name) sp = n[1]; });
    return name ? 'انْتَهَى وَقْتُ ' + (sp || name) : 'انْتَهَى الْوَقْت';
  }
  function tmLeft() { return !tm ? 0 : tm.paused !== null && tm.paused !== undefined ? tm.paused : Math.max(0, tm.end - Date.now()); }
  function startTimer(sec, name) {
    if (!(sec > 0)) return;
    tm = { end: Date.now() + sec * 1000, dur: sec * 1000, name: name || '', paused: null };
    Store.set('timer', tm);
    if (HF && HF.ttsEnsure) HF.ttsEnsure(JSON.stringify([tmSay(tm.name)]));
    renderTimer(); updatePill(); publishSoon();
  }
  function cancelTimer() { tm = null; Store.set('timer', null); renderTimer(); updatePill(); publishSoon(); }
  function pauseTimer() {
    if (!tm) return;
    if (tm.paused === null || tm.paused === undefined) tm.paused = tmLeft(); else { tm.end = Date.now() + tm.paused; tm.paused = null; }
    Store.set('timer', tm); renderTimer(); updatePill();
  }
  function plusMinute() { if (!tm) return; if (tm.paused !== null && tm.paused !== undefined) tm.paused += 60000; else tm.end += 60000; tm.dur += 60000; Store.set('timer', tm); renderTimer(); }
  function finishTimer() {
    var name = tm ? tm.name : '';
    tm = null; Store.set('timer', null); renderTimer(); updatePill(); publishSoon();
    $('td-name').textContent = name ? 'انتهى وقت ' + name : 'انتهى الوقت';
    $('tmdone').className = 'overlay show';
    /* ينطق الاسم أولاً ثم يرن، ويتوقف الرنين وحده بعد دقيقة */
    if (HF && HF.playSequenceWait) { tmSaying = true; HF.playSequenceWait(JSON.stringify([{ t: 'say', text: tmSay(name) }])); }
    else chime();
    clearTimeout(tmRingTimer); tmRingTimer = setTimeout(stopTimerRing, 60000);
  }
  function tmRing() { if ($('tmdone').className.indexOf('show') >= 0 && HF && HF.alarmStart) HF.alarmStart(); }
  function stopTimerRing() { tmSaying = false; clearTimeout(tmRingTimer); $('tmdone').className = 'overlay'; if (HF && HF.alarmStop) HF.alarmStop(); if (HF && HF.stopAudio) HF.stopAudio(); }
  function tickTimer() { if (tm && (tm.paused === null || tm.paused === undefined) && Date.now() >= tm.end) finishTimer(); }
  var ARC = 565.49;
  function renderTimer() {
    var run = !!tm;
    $('tm-setup').style.display = run ? 'none' : '';
    $('tm-run').style.display = run ? '' : 'none';
    if (!run) {
      $('tm-h').textContent = tmSet.h; $('tm-m').textContent = pad(tmSet.m); $('tm-s').textContent = pad(tmSet.s);
      return;
    }
    var left = tmLeft(), frac = tm.dur > 0 ? left / tm.dur : 0, arc = $('tm-arc');
    arc.style.strokeDashoffset = (ARC * (1 - frac)).toFixed(1);
    arc.style.stroke = 'hsl(' + Math.round(120 * frac) + ',72%,52%)';
    $('tm-left').textContent = fmtDur(Math.ceil(left / 1000) * 1000);
    $('tm-name').textContent = tm.name ? 'وقت ' + tm.name : '';
    $('tm-pause').textContent = tm.paused !== null && tm.paused !== undefined ? 'استئناف' : 'إيقاف مؤقت';
  }
  function renderTmChips() {
    var h = ''; each(TM_NAMES, function (n) { h += '<button data-n="' + n[0] + '"' + (n[0] === tmName ? ' class="on"' : '') + '>' + n[1] + '</button>'; });
    $('tm-names').innerHTML = h;
    h = ''; each(TM_PRE, function (p) { h += '<button data-sec="' + p[0] + '">' + p[1] + '</button>'; });
    $('tm-pre').innerHTML = h;
  }
  function stepTimer(k, d) {
    var max = k === 'h' ? 23 : 59;
    tmSet[k] = (tmSet[k] + d + max + 1) % (max + 1);
    renderTimer();
  }

  /* ساعة الإيقاف مع اللفّات */
  var sw = Store.get('sw', null) || { start: null, acc: 0, laps: [] };
  function swElapsed() { return sw.acc + (sw.start ? Date.now() - sw.start : 0); }
  function renderSw() {
    var on = !!sw.start, el = swElapsed();
    $('sw-time').textContent = fmtDur(el, true);
    $('sw-a').textContent = on ? 'إيقاف' : el ? 'استئناف' : 'ابدأ';
    $('sw-a').className = 'btn ' + (on ? 'danger' : 'primary');
    $('sw-b').textContent = on ? 'لفّة' : 'تصفير';
    $('sw-b').disabled = !on && !el;
    var h = '', prev = 0;
    each(sw.laps, function (t, i) { h = '<div class="lap"><span>لفّة ' + ar(i + 1) + '</span><span class="lapd">+' + fmtDur(t - prev, true) + '</span><b>' + fmtDur(t, true) + '</b></div>' + h; prev = t; });
    $('sw-laps').innerHTML = h;
  }
  function swMain() { if (sw.start) { sw.acc += Date.now() - sw.start; sw.start = null; } else sw.start = Date.now(); Store.set('sw', sw); renderSw(); updatePill(); }
  function swSide() {
    if (sw.start) { if (sw.laps.length < 99) sw.laps.push(swElapsed()); }
    else sw = { start: null, acc: 0, laps: [] };
    Store.set('sw', sw); renderSw(); updatePill();
  }

  /* شريط علوي صغير يظهر في كل الصفحات أثناء عمل المؤقت أو ساعة الإيقاف؛ الضغط عليه يفتحهما */
  function updatePill() {
    var parts = [];
    if (tm) parts.push('<span data-go="timer">⏳ ' + fmtDur(Math.ceil(tmLeft() / 1000) * 1000) + (tm.name ? ' · ' + esc(tm.name) : '') + (tm.paused !== null && tm.paused !== undefined ? ' ⏸' : '') + '</span>');
    if (sw.start) parts.push('<span data-go="sw">⏱ ' + fmtDur(swElapsed()) + '</span>');
    var showIt = parts.length && cur !== 'alarm';
    $('tpill').innerHTML = parts.join('');
    $('tpill').className = showIt ? 'show' : '';
    var b = document.body.className.replace(/\s*\bpill\b/g, '');
    if (b + (showIt ? ' pill' : '') !== document.body.className) document.body.className = b + (showIt ? ' pill' : '');
  }

  /* ---------- المهام اليومية: يضيفها الأدمن (القائمة المخفية، زر «+ مهمة»، الجوال) بأي اسم ----------
     عند بدايتها يُعلَن «حان الآن وقت … يا …» بصوت الإطار نفسه، وإن كان لها مدة يُعلَن عند نهايتها «انتهى وقت … يا …».
     تظهر في صفحة المهام مع الصلوات ليضع كل ابن صح عند الإنجاز. days فارغة = كل يوم، kids فارغة = لكل الأبناء */
  var TK_NAMES = [['حفظ القرآن', 'حِفْظِ الْقُرْآن'], ['مراجعة الحفظ', 'مُرَاجَعَةِ الْحِفْظ'], ['قراءة القرآن', 'قِرَاءَةِ الْقُرْآن'], ['المذاكرة', 'الْمُذَاكَرَة'],
    ['حل الواجبات', 'حَلِّ الْوَاجِبَات'], ['القراءة', 'الْقِرَاءَة'], ['ترتيب الغرفة', 'تَرْتِيبِ الْغُرْفَة'], ['الرياضة', 'الرِّيَاضَة'], ['الاستحمام', 'الِاسْتِحْمَام'],
    ['تنظيف الأسنان', 'تَنْظِيفِ الْأَسْنَان'], ['النوم', 'النَّوْم']];
  var tasks = Store.get('tasks', []), tkKids = null, tcTimer = null;
  /* المهام القديمة (قبل خانات الصح) تُحتسب من يوم التحديث فقط، فلا تنزل نسب الأيام الماضية */
  (function () { if (w.clockOk && !w.clockOk()) return; var d = ymd(new Date()), ch = false; each(tasks, function (t) { if (!t.from) { t.from = d; ch = true; } }); if (ch) Store.set('tasks', tasks); })();
  function saveTasks() { Store.set('tasks', tasks); publishSoon(); ensureTts(); lanSoon(); }
  function taskOn(t, date) { return t.on !== false && (!t.days || !t.days.length || t.days.indexOf(date.getDay()) >= 0); }
  function kidsOf(t) { var out = []; each(cfg.kids, function (k) { if ((t.kids || []).indexOf(k.id) >= 0) out.push(k); }); return out; }
  function taskSpoken(t) { var sp = t.name; each(TK_NAMES, function (n) { if (n[0] === t.name) sp = n[1]; }); return sp; }
  function taskWho(t) { var ks = kidsOf(t).map(function (k) { return nameSpoken(k.name); }); return ks.length ? ' يَا ' + ks.join(' وَ') : ''; }
  function taskSay(t) { return 'حَانَ الْآنَ وَقْتُ ' + taskSpoken(t) + taskWho(t); }
  function taskEndSay(t) { return 'انْتَهَى وَقْتُ ' + taskSpoken(t) + taskWho(t); }
  /* مدة المهمة بالدقائق → «ساعتين و٢٠ دقيقة»، «ساعة ونصف»، «٤٥ دقيقة» */
  function countAr(n, one, two, few, many) { return n === 1 ? one : n === 2 ? two : ar(n) + (n >= 3 && n <= 10 ? ' ' + few : ' ' + many); }
  function durText(m) {
    var h = Math.floor(m / 60), mm = m % 60, hs = h ? countAr(h, 'ساعة', 'ساعتين', 'ساعات', 'ساعة') : '';
    if (!mm) return hs;
    if (h && mm === 30) return hs + ' ونصف';
    var ms = countAr(mm, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة');
    return h ? hs + ' و' + ms : ms;
  }
  var TASK_MAX = 24 * 60 - 1;
  function taskEndHm(t) { var p = t.time.split(':'), m = (+p[0] * 60 + +p[1] + t.dur) % 1440; return pad(Math.floor(m / 60)) + ':' + pad(m % 60); }
  /* end = إعلان انتهاء الوقت */
  function fireTask(t, end) {
    $('tc-lbl').textContent = end ? 'انتهى الوقت' : 'حان الآن وقت';
    $('tc-name').textContent = end ? 'انتهى وقت ' + t.name : t.name;
    $('tc-kids').innerHTML = kidsOf(t).map(function (k) { return '<span class="kidtag">' + esc(k.name) + '</span>'; }).join('');
    $('tc-dur').textContent = end ? 'لا تنسَ وضع ✓ في صفحة المهام إن أنجزتها' : t.dur ? 'المدة ' + durText(t.dur) + ' — تنتهي الساعة ' + t12(taskEndHm(t)) : 'ضع ✓ في صفحة المهام عند الإنجاز';
    $('taskcall').className = 'overlay show';
    clearTimeout(tcTimer); tcTimer = setTimeout(function () { $('taskcall').className = 'overlay'; }, 3 * 60000);
    if (HF && HF.playSequenceWait) HF.playSequenceWait(JSON.stringify([{ t: 'say', text: end ? taskEndSay(t) : taskSay(t) }])); else chime();
  }
  function tickTasks(now) {
    var key = ymd(now) + hm(now), nm = now.getHours() * 60 + now.getMinutes(), changed = false;
    each(tasks, function (t) {
      if (t.time === hm(now) && taskOn(t, now) && t.last !== key) { t.last = key; changed = true; fireTask(t, false); return; }
      if (!t.dur || t.lastEnd === key || taskEndHm(t) !== hm(now)) return;
      /* النهاية قد تقع بعد منتصف الليل: تُنسب لليوم الذي بدأت فيه المهمة */
      var p = t.time.split(':'), startDay = +p[0] * 60 + +p[1] + t.dur >= 1440 && nm < +p[0] * 60 + +p[1] ? dayOff(now, -1) : now;
      if (!taskOn(t, startDay)) return;
      t.lastEnd = key; changed = true; fireTask(t, true);
    });
    if (changed) { Store.set('tasks', tasks); if (cur === 'tasks') renderTasks(); }
  }
  /* صفحة المهام: بطاقة لكل ابن فيها الصلوات ومهامه اليوم. ما حلّ وقته يُضغط لوضع صح، وما لم يحن يظهر باهتاً بوقته */
  function minsLeftText(ms) { var m = Math.ceil(ms / 60000); return m >= 60 ? 'يبقى ' + durText(Math.round(m / 5) * 5 || m) : 'يبقى ' + countAr(m, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة'); }
  function renderTasks() {
    var now = new Date(), today = ymd(now), h = '', n = cfg.kids.length, land = w.innerWidth >= w.innerHeight;
    $('tk-sub').textContent = L.AR_DAYS[now.getDay()] + ' · اضغط على المهمة عند إنجازها';
    each(cfg.kids, function (kid, idx) {
      var s = kidScore(kid.id, now, now), tiles = '';
      each(kidItems(kid.id, now), function (it) {
        var ok = recHas(kid.id, it.key, today), due = it.at <= now, run = it.end && due && now < it.end;
        tiles += '<div class="tki' + (ok ? ' ok' : due ? ' due' : ' soon') + (it.pr ? ' pr' : '') + (run ? ' run' : '') + '" data-k="' + kid.id + '" data-p="' + esc(it.key) + '"><div>' +
          '<span class="ck">' + (ok ? '✓' : '') + '</span><span class="tkn"><b>' + esc(it.name) + '</b><small>' + (run ? minsLeftText(it.end - now) : t12(hm(it.at))) + '</small></span></div></div>';
      });
      h += '<div class="kcard c' + (idx % 4) + '"><div><div class="khead"><b>' + esc(kid.name) + '</b><span class="kpct ' + pctLevel(s.pct) + '">' + pctText(s.pct) + '</span></div>' +
        '<div class="tkgrid">' + tiles + '</div></div></div>';
    });
    $('tk-list').className = 'tkwrap ' + (n <= 1 || (!land && n <= 3) ? 'w1' : land && n >= 3 ? 'w3' : 'w2') + (n >= 3 ? ' tight' : '');
    $('tk-list').innerHTML = h || '<div class="empty">أضف الأبناء من القائمة المخفية أو من الجوال</div>';
  }
  function upsertTask(x) {
    var t = null; each(tasks, function (y) { if (y.id === x.id) t = y; });
    if (!t) {
      /* مهمة جديدة فات وقتها اليوم تبدأ من الغد، حتى لا تنزل نسبة اليوم بشيء لم يُطلب في وقته */
      var now = new Date();
      t = { id: x.id || newId(), from: x.time < hm(now) ? ymd(dayOff(now, 1)) : ymd(now) }; tasks.push(t);
    }
    t.name = String(x.name || '').substr(0, 30); t.time = x.time; t.days = (x.days || []).filter(function (d) { return d >= 0 && d <= 6; });
    t.kids = (x.kids || []).slice(0, 6); t.dur = Math.max(0, Math.min(TASK_MAX, Math.round(+x.dur || 0))); t.on = x.on !== false; t.last = ''; t.lastEnd = '';
    saveTasks();
    return t;
  }
  function delTask(id) { tasks = tasks.filter(function (t) { return t.id !== id; }); saveTasks(); }
  function taskDaysText(days) {
    if (!days || !days.length || days.length === 7) return 'كل يوم';
    var s = []; each(AL_ORDER, function (d) { if (days.indexOf(d) >= 0) s.push(L.AR_DAYS[d]); }); return s.join('، ');
  }
  /* full: من القائمة المخفية (قائمة المهام مع الإيقاف والحذف)؛ وإلا من زر «+ مهمة» في الصفحة (إضافة فقط) */
  var teFull = true;
  function openTaskEdit(full) {
    teFull = !!full;
    $('te-title').textContent = full ? 'المهام اليومية' : 'مهمة جديدة';
    $('te-list').style.display = full ? '' : 'none';
    $('te-newlbl').style.display = full ? '' : 'none';
    tkKids = cfg.kids.map(function (k) { return k.id; });
    $('te-name').value = ''; setTimeFields('te-th', 'te-tm', 'te-tap', '16:00'); $('te-dh').value = '0'; $('te-dm').value = '0';
    each(document.querySelectorAll('#te-days button'), function (b) { b.className = ''; });
    $('te-names').innerHTML = TK_NAMES.map(function (n) { return '<button data-n="' + n[0] + '">' + n[0] + '</button>'; }).join('');
    renderTkKids(); renderTaskManage(); $('taskedit').className = 'overlay show';
  }
  function renderTkKids() { $('te-kids').innerHTML = cfg.kids.map(function (k) { return '<button data-k="' + k.id + '"' + (tkKids.indexOf(k.id) >= 0 ? ' class="on"' : '') + '>' + esc(k.name) + '</button>'; }).join(''); }
  function renderTaskManage() {
    var h = '';
    each(tasks.slice().sort(function (a, b) { return a.time < b.time ? -1 : 1; }), function (t) {
      h += '<div class="evrow' + (t.on === false ? ' off' : '') + '"><span class="what">' + t12(t.time) + ' · ' + esc(t.name) + '<br><small class="emwhen">' + taskDaysText(t.days) +
        (kidsOf(t).length ? ' · ' + kidsOf(t).map(function (k) { return esc(k.name); }).join('، ') : '') + (t.dur ? ' · ' + durText(t.dur) : '') + '</small></span>' +
        '<button class="altog' + (t.on !== false ? ' on' : '') + '" data-tog="' + t.id + '"><i></i></button><button class="del" data-id="' + t.id + '">حذف</button></div>';
    });
    $('te-list').innerHTML = h || '<div class="empty">لا توجد مهام بعد</div>';
  }

  /* ---------- لوحة العائلة: رسائل وصور يضيفها الأدمن من الجوال أو القائمة المخفية ---------- */
  function saveBoard() { Store.set('board', board); publishSoon(); }
  function boardDate(ts) { var d = new Date(ts); return ar(d.getDate()) + ' ' + L.AR_MONTHS[d.getMonth()]; }
  function renderBoard() {
    var h = '';
    each(board, function (b) {
      if (b.k === 'photo') h += '<div class="botile ph" data-pv="' + b.id + '"><img src="' + esc(b.f) + '" alt="">' + (b.t ? '<span>' + esc(b.t) + '</span>' : '') + '</div>';
      else h += '<div class="botile nt nc' + (b.c || 0) + '" data-pv="' + b.id + '"><p>' + esc(b.t) + '</p><small>' + boardDate(b.ts) + '</small></div>';
    });
    $('bo-list').innerHTML = h || '<div class="empty">اللوحة فاضية — يضيف الأدمن الصور والرسائل من الجوال</div>';
  }
  /* العارض: صورة كاملة أو رسالة كبيرة، والسحب يميناً/يساراً (أو الأسهم) ينقل للعنصر التالي والسابق.
     يُغلق وحده بعد ٣ دقائق بلا لمس حتى يعود تدوير الصفحات */
  var pvIdx = 0, pvTimer = null;
  function openViewer(id) {
    each(board, function (b, i) { if (b.id === id) pvIdx = i; });
    renderViewer(); $('photoview').className = 'overlay show';
  }
  function renderViewer() {
    var n = board.length, b = board[pvIdx];
    if (!b) { $('photoview').className = 'overlay'; return; }
    $('pv-box').innerHTML = b.k === 'photo' ? '<img src="' + esc(b.f) + '" alt="">' + (b.t ? '<div class="pvcap">' + esc(b.t) + '</div>' : '')
      : '<div class="pvnote nc' + (b.c || 0) + '"><p>' + esc(b.t) + '</p><small>' + boardDate(b.ts) + '</small></div>';
    $('pv-idx').textContent = ar(pvIdx + 1) + ' / ' + ar(n);
    $('pv-prev').style.visibility = $('pv-next').style.visibility = n > 1 ? '' : 'hidden';
    clearTimeout(pvTimer); pvTimer = setTimeout(function () { $('photoview').className = 'overlay'; }, 3 * 60000);
  }
  function pvMove(d) { var n = board.length; if (n < 2) return; pvIdx = (pvIdx + d + n) % n; renderViewer(); }
  function trimBoard() {
    while (board.length > 40) { var x = board.pop(); if (x.k === 'photo' && HF && HF.deleteImage) HF.deleteImage(x.id); }
  }
  function addNote(id, text, c) {
    text = String(text || '').replace(/^\s+|\s+$/g, '').substr(0, 200); if (!text) return;
    board = board.filter(function (b) { return b.id !== id; });
    board.unshift({ id: id || newId(), k: 'note', t: text, c: +c || 0, ts: Date.now() });
    trimBoard(); saveBoard(); if (cur === 'board') renderBoard();
  }
  function addPhoto(id, url, caption) {
    if (!HF || !HF.downloadImage) return;
    var cbid = 'c' + (++cbn);
    cbs[cbid] = function (ok, path) {
      if (!ok) { toast('تعذّر تحميل الصورة'); return; }
      board = board.filter(function (b) { return b.id !== id; });
      board.unshift({ id: id, k: 'photo', f: path + '?' + Date.now(), t: String(caption || '').substr(0, 80), ts: Date.now() });
      trimBoard(); saveBoard(); if (cur === 'board') renderBoard(); toast('وصلت صورة جديدة للوحة العائلة');
    };
    HF.downloadImage(url, id, cbid);
  }
  function delBoard(id) {
    each(board, function (b) { if (b.id === id && b.k === 'photo' && HF && HF.deleteImage) HF.deleteImage(id); });
    board = board.filter(function (b) { return b.id !== id; }); saveBoard(); if (cur === 'board') renderBoard();
    if ($('photoview').className.indexOf('show') >= 0) { if (pvIdx >= board.length) pvIdx = 0; renderViewer(); }
  }
  var boColor = 0;
  function openBoardEdit() {
    $('bo-text').value = ''; boColor = 0;
    each(document.querySelectorAll('#bo-colors button'), function (b) { b.className = 'nc' + b.getAttribute('data-c') + (b.getAttribute('data-c') === '0' ? ' on' : ''); });
    renderBoardManage(); $('boedit').className = 'overlay show';
  }
  function renderBoardManage() {
    var h = '';
    each(board, function (b) { h += '<div class="evrow"><span class="what">' + (b.k === 'photo' ? '📷 ' + esc(b.t || 'صورة') : esc(b.t)) + '<br><small class="emwhen">' + boardDate(b.ts) + '</small></span><button class="del" data-id="' + b.id + '">حذف</button></div>'; });
    $('bo-manage').innerHTML = h;
  }

  /* ---------- تذكير المواعيد بالصوت ---------- */
  var evCalls = Store.get("evcalls", {}), rmTimer = null;
  function timeSpeech(t) {
    var p = t.split(":"), h = +p[0], m = +p[1], h12 = h % 12 || 12;
    return "السَّاعَةُ " + h12 + (m ? " وَ" + m + " دَقِيقَة" : "") + (h < 12 ? " صَبَاحاً" : " مَسَاءً");
  }
  function evSay(type, e) {
    var birthday = e.kind === "birthday";
    if (type === "pre") return "تَذْكِير، بَعْدَ سَاعَةٍ، مَوْعِدُ " + e.title;
    if (type === "now") return "حَانَ الْآنَ مَوْعِدُ " + e.title;
    return birthday ? "الْيَوْمَ يَوْمُ مِيلَادِ " + e.title : "الْيَوْمَ مَوْعِدُ " + e.title;
  }
  function sayNow(text) { if (HF && HF.playSequenceWait) HF.playSequenceWait(JSON.stringify([{ t: "say", text: text }])); }
  function showRemind(type, e) {
    $("rm-label").textContent = type === "pre" ? "بعد ساعة" : type === "now" ? "حان موعدك" : "اليوم";
    $("rm-title").textContent = (e.kind === "birthday" ? "يوم ميلاد " : "") + e.title + (e.kind === "birthday" ? " 🎂" : "");
    $("rm-time").textContent = e.time ? t12(e.time) : "";
    $("remind").className = "overlay show";
    clearTimeout(rmTimer); rmTimer = setTimeout(function () { $("remind").className = "overlay"; }, 90000);
  }
  function tickEvents(now) {
    var list = eventsOn(now), nowMin = now.getHours() * 60 + now.getMinutes(), y = ymd(now), fired = false, due = [];
    each(list, function (e) {
      var type = null;
      if (e.time) {
        var p = e.time.split(":"), m = +p[0] * 60 + +p[1];
        if (nowMin === m - 60) type = "pre"; else if (nowMin === m) type = "now";
      } else if (now.getHours() === 8 && now.getMinutes() < 5) type = "day";
      if (!type || evCalls[type + y + e.id]) return;
      evCalls[type + y + e.id] = 1; fired = true;
      due.push({ type: type, e: e });
    });
    /* تذكيرات الدقيقة نفسها: شاشة واحدة وقراءة متتابعة بدل أن يقطع أحدها الآخر */
    if (due.length === 1) showRemind(due[0].type, due[0].e);
    else if (due.length > 1) {
      showRemind(due[0].type, due[0].e);
      $("rm-label").textContent = "تذكير بمواعيد";
      $("rm-title").textContent = due.map(function (d) { return d.e.title; }).join(" · ");
      $("rm-time").textContent = "";
    }
    if (due.length && HF && HF.playSequenceWait) HF.playSequenceWait(JSON.stringify(due.map(function (d) { return { t: "say", text: evSay(d.type, d.e) }; })));
    if (fired) { var keep = {}; for (var k in evCalls) if (k.indexOf(y) >= 0) keep[k] = 1; evCalls = keep; Store.set("evcalls", evCalls); }
  }
  function readToday() {
    var list = eventsOn(new Date()), parts = [];
    each(list, function (e) { parts.push(e.title + (e.time ? "، " + timeSpeech(e.time) : "")); });
    var text = parts.length ? "مَوَاعِيدُ الْيَوْمِ: " + parts.join("، ثُمَّ ") : "لَا تُوجَدُ مَوَاعِيدُ الْيَوْمَ";
    toast("جارٍ القراءة…"); sayNow(text);
  }
  /* ---------- الشبكة (واي فاي) من داخل التطبيق ---------- */
  var wfSel = null, wfPoll = null;
  function wfBars(l) { return ["▁", "▃", "▅", "▇", "█"][Math.max(0, Math.min(4, l))]; }
  function wfCurrent() {
    var c = HF && HF.wifiCurrent ? HF.wifiCurrent() : "";
    $("wf-cur").textContent = c ? "متصل بـ: " + c : "غير متصل";
    return c;
  }
  function wfScan() {
    if (!HF || !HF.wifiScanStart) { $("wf-list").innerHTML = '<div class="empty">غير متاح</div>'; return; }
    $("wf-list").innerHTML = '<div class="empty">جارٍ البحث عن الشبكات…</div>';
    HF.wifiScanStart();
    setTimeout(function () {
      var list = []; try { list = JSON.parse(HF.wifiResults()); } catch (e) { }
      var html = "";
      each(list, function (n) { html += '<div class="wfrow" data-s="' + esc(n.s) + '" data-k="' + (n.k ? 1 : 0) + '"><span>' + esc(n.s) + '</span><span class="wfs">' + (n.k ? "🔒 " : "") + wfBars(n.l) + "</span></div>"; });
      $("wf-list").innerHTML = html || '<div class="empty">لم يتم العثور على شبكات، اضغط تحديث</div>';
    }, 3500);
  }
  function openWifi() { wfSel = null; $("wf-pass").style.display = "none"; $("wf-list").style.display = ""; wfCurrent(); $("wifi").className = "overlay show"; wfScan(); }
  function wfConnect(ssid, pass) {
    toast("جارٍ الاتصال بـ " + ssid + "…");
    var ok = HF && HF.wifiConnect ? HF.wifiConnect(ssid, pass) : false;
    if (!ok) { toast("تعذّر إضافة الشبكة"); return; }
    var tries = 0; clearInterval(wfPoll);
    wfPoll = setInterval(function () {
      tries++; var c = wfCurrent();
      if (c === ssid) { clearInterval(wfPoll); toast("تم الاتصال بـ " + ssid); loadWeather(); }
      else if (tries > 12) { clearInterval(wfPoll); toast("لم يتم الاتصال، تحقق من كلمة المرور"); }
    }, 2000);
  }
  /* ---------- اختيار المدينة (يضبط مواقيت الصلاة والطقس) ---------- */
  var CITIES = [["مكة المكرمة", 21.4225, 39.8262], ["المدينة المنورة", 24.4672, 39.6112], ["الرياض", 24.7136, 46.6753], ["جدة", 21.4858, 39.1925], ["الدمام", 26.4207, 50.0888], ["الطائف", 21.2703, 40.4158], ["أبها", 18.2164, 42.5053], ["تبوك", 28.3835, 36.5662], ["الكويت", 29.3759, 47.9774], ["المنامة", 26.2285, 50.586], ["الدوحة", 25.2854, 51.531], ["أبوظبي", 24.4539, 54.3773], ["دبي", 25.2048, 55.2708], ["مسقط", 23.588, 58.3829]];
  function openCity() {
    $("ct-cur").textContent = "المدينة الحالية: " + cfg.city;
    var html = ""; each(CITIES, function (c, i) { html += '<div class="wfrow' + (c[0] === cfg.city ? " cur" : "") + '" data-i="' + i + '"><span>' + c[0] + "</span><span>" + (c[0] === cfg.city ? "✓" : "") + "</span></div>"; });
    $("ct-list").innerHTML = html; $("citybox").className = "overlay show";
  }
  function pickCity(i) {
    var c = CITIES[i]; if (!c) return;
    cfg.city = c[0]; cfg.lat = c[1]; cfg.lng = c[2]; tcache = {};
    saveCfg(); publishSoon(); loadWeather(); renderAll(); openCity(); toast("تم ضبط المواقيت على " + c[0]);
  }
  /* ---------- إدارة المواعيد (من القائمة المخفية) ---------- */
  var REP_AR = { none: "", weekly: " · كل أسبوع", monthly: " · كل شهر", yearly: " · كل سنة" };
  function openEvManage() {
    var list = events.slice().sort(function (a, b) { return (a.date + (a.time || "")) < (b.date + (b.time || "")) ? -1 : 1; });
    var html = "";
    each(list, function (e) {
      var d = L.parseYmd(e.date);
      var when = ar(d.getDate()) + " " + L.AR_MONTHS[d.getMonth()] + (e.repeat === "yearly" ? "" : " " + ar(d.getFullYear())) + (e.time ? " · " + t12(e.time) : "") + (REP_AR[e.repeat] || "");
      html += '<div class="evrow' + (e.kind === "birthday" ? " b" : "") + '"><span class="what">' + esc(e.title) + (e.kind === "birthday" ? " 🎂" : "") + '<br><small class="emwhen">' + when + '</small></span><button class="del" data-id="' + e.id + '">حذف</button></div>';
    });
    $("em-list").innerHTML = html || '<div class="empty">لا توجد مواعيد محفوظة</div>';
    $("evmanage").className = "overlay show";
  }
  var toastTimer = null;
  function toast(msg) { var t = $('toast'); t.textContent = msg; t.className = 'show'; clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.className = ''; }, 4000); }
  w.toast = toast;
  w.onAudioFail = function (msg) {
    if (soundNow) { soundNow = null; $('sndbar').className = ''; lanSoon(); toast('تعذّر تشغيل هذا الصوت'); return; }
    if (tmSaying) { tmSaying = false; tmRing(); return; }
    var wasSpeaking = speaking;
    if (speaking) { speaking = false; setSpk(false); }
    toast(wasSpeaking ? 'تعذّر تحميل القراءة، تأكد من الإنترنت' : 'تعذّر تشغيل الصوت، تأكد من الإنترنت');
    if (!wasSpeaking) chime();
  };

  /* ---------- القائمة ---------- */
  /* إعدادات أندرويد لا تُفتح إلا بقرار مقصود: لمسات سريعة زائدة بعد فتح القائمة لا تُحتسب، ثم نافذة تأكيد
     زرّ «إلغاء» فيها يقع تحت موضع الزر نفسه، فاللمس المتكرر في المكان نفسه يلغي ولا يفتح */
  var menuAt = 0, confirmAt = 0;
  function pressSettings() {
    if (Date.now() - menuAt < 1500) return;
    confirmAt = Date.now(); $('setconfirm').className = 'overlay show';
  }
  function confirmSettings() {
    if (Date.now() - confirmAt < 1000) return;
    closeAll();
    if (HF) HF.openAndroidSettings();
  }
  function openMenu() {
    menuAt = Date.now();
    $('m-ramv').textContent = cfg.forceRamadan ? 'مفعّل يدوياً' : 'تلقائي';
    $('m-eidv').textContent = cfg.forceEid ? 'مفعّل يدوياً' : 'تلقائي';
    $('m-rotv').textContent = cfg.rotate ? 'نعم' : 'لا';
    var ip = HF && HF.getIp ? HF.getIp() : '';
    $('m-info').textContent = menuInfo();
    renderQr(ip);
    try { $('m-vol').value = HF && HF.getVolume ? HF.getVolume() : 50; } catch (e) { }
    $('menu').className = 'overlay show';
  }
  /* باركود التحكم: عنوان الإطار في الشبكة الحالية + رمزه، فيتغيّر تلقائياً إذا تغيّرت الشبكة */
  function renderQr(ip) {
    var ok = ip && ip !== '0.0.0.0' && w.qrcode;
    $('m-qr').className = 'qrcard' + (ok ? '' : ' off');
    if (!ok) { $('m-qrimg').removeAttribute('src'); $('m-qrurl').textContent = ''; $('m-qrnet').textContent = 'الإطار غير متصل بشبكة واي فاي — اتصل بالشبكة أولاً'; return; }
    var url = 'http://' + ip + ':8080/#' + secret;
    try { var q = w.qrcode(0, 'M'); q.addData(url); q.make(); $('m-qrimg').src = q.createDataURL(8, 2); } catch (e) { }
    var ssid = HF && HF.wifiCurrent ? HF.wifiCurrent() : '';
    $('m-qrnet').textContent = 'امسح الرمز بكاميرا الجوال وهو متصل بنفس الشبكة' + (ssid ? ' «' + ssid + '»' : '');
    $('m-qrurl').textContent = url;
  }
  function closeLog(tag) { var l = (w.__closeLog = w.__closeLog || []); l.push(new Date().toTimeString().slice(0, 8) + ' ' + tag + ' ' + String(new Error().stack || '').split(String.fromCharCode(10)).slice(2, 5).join(' < ')); if (l.length > 30) l.shift(); }
  function closeAll() {
    closeLog('closeAll');
    var any = false;
    each(document.querySelectorAll('.overlay.show'), function (o) { if (o.id === 'call') { hideCall(); } if (o.id === 'alarmring') { stopAlarm(); } if (o.id === 'tmdone') { stopTimerRing(); } o.className = 'overlay'; any = true; });
    if (HF && HF.hideKeyboard) HF.hideKeyboard();
    return any;
  }
  w.onMenuKey = function () { if ($('menu').className.indexOf('show') < 0) openMenu(); else closeAll(); };
  w.onBack = function () { if (!closeAll()) { show('home'); lastTouch = Date.now(); } };

  /* ---------- التحكم عن بعد (ntfy) ---------- */
  /* رمز الإطار السري: يُولَّد مرة عند أول تشغيل ويُحفظ، فلكل نسخة رمزها (الإطار الأول احتفظ برمزه القديم من config.js) */
  function genSecret() {
    var a = [], i, r = new Uint8Array(10);
    try { w.crypto.getRandomValues(r); } catch (e) { for (i = 0; i < 10; i++) r[i] = Math.floor(Math.random() * 256); }
    for (i = 0; i < 10; i++) a.push(('0' + r[i].toString(16)).slice(-2));
    return a.join('');
  }
  if (!cfg.secret) { cfg.secret = (w.OTMO_CFG || {}).secret || genSecret(); saveCfg(); }
  var secret = cfg.secret;
  var T_CMD = 'otmo-' + secret + '-cmd', T_STATE = 'otmo-' + secret + '-state';
  var seen = {}, pubTimer = null;
  /* حالة الإطار التي تقرؤها صفحة الجوال (رسالة ntfy واحدة، أقل من ٤ كيلوبايت) */
  function statePayload() {
    var evs = events.map(function (e) { var o = { i: e.id, t: e.title, d: e.date, h: e.time || '', r: e.repeat || 'none', k: e.kind || 'event' }; if (e.emoji) o.e = e.emoji; return o; });
    var al = alarms.map(function (a) { return { i: a.id, h: a.time, l: a.label || '', d: a.days || [], o: !!a.on }; });
    var bd = board.map(function (b) { return { i: b.id, k: b.k, t: String(b.t || '').substr(0, 40), c: b.c || 0, s: b.ts }; });
    var tk = tasks.map(function (t) { return { i: t.id, n: t.name, h: t.time, d: t.days || [], k: t.kids || [], m: t.dur || 0, o: t.on !== false }; });
    var vol = 50; try { vol = HF && HF.getVolume ? HF.getVolume() : 50; } catch (e) { }
    var p = { v: 2, ts: Date.now(), name: cfg.name, city: cfg.city, lat: cfg.lat, lng: cfg.lng, fr: !!cfg.forceRamadan, fe: !!cfg.forceEid, rot: !!cfg.rotate, vol: vol,
      tabs: cfg.tabs, kids: cfg.kids, prize: cfg.prize || '', adh: cfg.adh, ev: evs, al: al, bd: bd, tk: tk, tm: tm ? { e: tm.end, n: tm.name, p: tm.paused } : null };
    var c = champOf(new Date()), lm = new Date(); lm = champOf(new Date(lm.getFullYear(), lm.getMonth() - 1, 1));
    p.champ = { m: c.m, list: c.list.map(function (x) { return { n: x.name, c: x.n }; }), last: { m: lm.m, win: lm.win.map(function (x) { return x.name; }), c: lm.top } };
    var today = ymd(new Date());
    if (JSON.stringify(p).length > 3800) each(p.bd, function (b) { b.t = b.t.substr(0, 14); });
    while (JSON.stringify(p).length > 3800 && p.bd.length > 10) p.bd.pop();
    while (JSON.stringify(p).length > 3800 && p.ev.length) {
      p.ev.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var idx = 0; for (var i = 0; i < p.ev.length; i++) { if (p.ev[i].r === 'none' && p.ev[i].d < today) { idx = i; break; } }
      p.ev.splice(idx, 1);
    }
    return p;
  }
  function publishState() { if (HF && HF.publish) { try { HF.publish(T_STATE, JSON.stringify(statePayload())); } catch (e) { } } lanPush(); }
  function publishSoon() { clearTimeout(pubTimer); pubTimer = setTimeout(publishState, 1500); }

  /* ---------- التحكم من الشبكة المنزلية (باركود القائمة المخفية) ----------
     الجوال يفتح http://IP:8080/#الرمز من الإطار نفسه، ويقرأ الحالة الكاملة ويرسل الأوامر والصور والأصوات مباشرة بلا إنترنت */
  var lanTimer = null;
  function lanPayload() {
    var p = statePayload();
    p.lan = 1; p.ts = Date.now();
    p.ev = events.map(function (e) { var o = { i: e.id, t: e.title, d: e.date, h: e.time || '', r: e.repeat || 'none', k: e.kind || 'event' }; if (e.emoji) o.e = e.emoji; return o; });
    p.bd = board.map(function (b) { return { i: b.id, k: b.k, t: String(b.t || ''), c: b.c || 0, s: b.ts }; });
    p.snd = sounds.map(function (x) { return { i: x.id, n: x.n, e: x.e, z: x.z, s: x.ts }; });
    p.now = soundNow;
    p.upd = updInfo(); if (updStatus) p.upd.status = updStatus;
    p.gcal = { on: !!icsUrl(), ts: gcal.ts || 0, n: gEvents.length, err: gcal.err || '' };
    /* تقرير الأبناء لآخر ٧ أيام: الجوال يعرضه ويعدّل خاناته (op: rec) */
    p.rep = cfg.kids.map(function (k) { var g = reportGrid(k.id, new Date(), 7, true); return { i: k.id, n: k.name, d: g.days.map(ymd), p: g.pct, r: g.rows.map(function (r) { return { p: r.p, n: r.n, c: r.c }; }) }; });
    return p;
  }
  function lanPush() { if (HF && HF.setLan) { try { HF.setLan(secret, JSON.stringify(lanPayload())); } catch (e) { } } }
  function lanSoon() { clearTimeout(lanTimer); lanTimer = setTimeout(lanPush, 400); }
  w.onLanCmd = function (body) {
    var c; try { c = JSON.parse(body); } catch (e) { return; }
    if (c && c.op === 'ics' && HF && HF.setConfig) {
      var u = String(c.url || '').replace(/^\s+|\s+$/g, '').replace(/^webcal:\/\//i, 'https://');
      if (u && !/^https:\/\/\S+$/.test(u)) return;
      HF.setConfig('ics', u); w.onIcsChanged(); lanSoon(); return;
    }
    applyCommand(c, null);
    lanSoon();
  };
  /* ملف وصل من الجوال: صورة للوحة العائلة أو صوت لمكتبة الأصوات */
  w.onLanFile = function (s) {
    var f; try { f = JSON.parse(s); } catch (e) { return; }
    if (f.type === 'photo') {
      board = board.filter(function (b) { return b.id !== f.id; });
      board.unshift({ id: f.id, k: 'photo', f: f.path + '?' + Date.now(), t: String(f.c || '').substr(0, 80), ts: Date.now() });
      trimBoard(); saveBoard(); if (cur === 'board') renderBoard(); toast('وصلت صورة جديدة للوحة العائلة');
    } else if (f.type === 'sound') {
      sounds = sounds.filter(function (x) { return x.id !== f.id; });
      sounds.unshift({ id: f.id, n: String(f.name || 'صوت').substr(0, 60), e: f.ext, z: f.size, ts: Date.now() });
      saveSounds(); toast('وصل صوت جديد: ' + sounds[0].n);
    }
    lanSoon();
  };

  /* ---------- الأصوات من الجوال: مكتبة على الإطار، تشغيل وإيقاف من الجوال ---------- */
  var sounds = Store.get('sounds', []), soundNow = null, soundAt = 0;
  function saveSounds() { Store.set('sounds', sounds); lanSoon(); }
  function findSound(id) { for (var i = 0; i < sounds.length; i++) if (sounds[i].id === id) return sounds[i]; return null; }
  function playSound(id) {
    var x = findSound(id); if (!x || !HF || !HF.playSound) return;
    stopSpeak();
    soundNow = id; soundAt = Date.now(); HF.playSound(x.id + '.' + x.e);
    $('sndname').textContent = x.n; $('sndbar').className = 'show';
    lanSoon();
  }
  function stopSound() {
    if (!soundNow) return;
    soundNow = null; $('sndbar').className = '';
    if (HF && HF.stopAudio) HF.stopAudio();
    lanSoon();
  }
  function delSound(id) {
    var x = findSound(id); if (!x) return;
    if (soundNow === id) stopSound();
    if (HF && HF.deleteSound) HF.deleteSound(x.id + '.' + x.e);
    sounds = sounds.filter(function (y) { return y.id !== id; }); saveSounds();
  }
  /* يُخفى شريط «يُشغَّل الآن» إذا انتهى الصوت أو أوقفه صوت آخر (نداء صلاة، أذكار…) */
  function tickSound() {
    if (!soundNow || !HF || !HF.audioInfo || Date.now() - soundAt < 4000) return;
    var a = String(HF.audioInfo()).split(',');
    if (+a[1] === 0) { soundNow = null; $('sndbar').className = ''; lanSoon(); }
  }
  /* أوامر صفحة الجوال: كل ما يمكن عمله على الإطار يمكن عمله من بعيد */
  function applyCommand(c, m) {
    if (!c || !c.op) return;
    if (c.op === 'add' && c.ev && c.ev.title && c.ev.date) {
      var ne = { id: c.ev.id || newId(), title: String(c.ev.title).substr(0, 80), date: c.ev.date, time: c.ev.time || '', repeat: c.ev.repeat || 'none', kind: c.ev.kind === 'birthday' ? 'birthday' : 'event' };
      if (ne.kind === 'birthday') { ne.repeat = 'yearly'; ne.time = ''; if (c.ev.emoji) ne.emoji = String(c.ev.emoji).substr(0, 4); }
      addEvent(ne);
    } else if (c.op === 'del' && c.id) { delEvent(c.id); }
    else if (c.op === 'cfg' && c.cfg) {
      var x = c.cfg;
      if (typeof x.city === 'string' && x.city) cfg.city = x.city.substr(0, 40);
      if (isFinite(x.lat) && isFinite(x.lng)) { cfg.lat = +x.lat; cfg.lng = +x.lng; tcache = {}; loadWeather(); }
      if (typeof x.fr === 'boolean') cfg.forceRamadan = x.fr;
      if (typeof x.fe === 'boolean') cfg.forceEid = x.fe;
      if (typeof x.rot === 'boolean') cfg.rotate = x.rot;
      if (typeof x.name === 'string' && x.name) cfg.name = x.name.substr(0, 30);
      if (x.tabs && x.tabs.length) { cfg.tabs = x.tabs.filter(function (p) { return PAGES.indexOf(p) >= 0; }); if (cfg.tabs.indexOf('home') < 0) cfg.tabs.unshift('home'); applyTabs(); }
      if (isFinite(x.vol) && HF && HF.setVolume) HF.setVolume(Math.max(0, Math.min(100, +x.vol)));
      if (x.adh && typeof x.adh === 'object') each(['m', 'e'], function (s) { var a = x.adh[s]; if (a) setAdh(s, a.on === false ? 'off' : a.at ? 'at' : a.min, a.at); });
      if (typeof x.prize === 'string') { cfg.prize = x.prize.replace(/^\s+|\s+$/g, '').substr(0, 80); if (cur === 'kids') renderKids(); }
      if (x.kids && x.kids.length) {
        cfg.kids = withSince(x.kids.slice(0, 6).map(function (k, i) { return { id: k.id || ('k' + (i + 1)), name: String(k.name || '').substr(0, 20) || ('ابن ' + (i + 1)) }; }));
      }
      saveCfg(); publishSoon(); ensureTts();
    } else if (c.op === 'alarm' && c.a && /^\d\d:\d\d$/.test(c.a.time)) {
      var a = null; each(alarms, function (y) { if (y.id === c.a.id) a = y; });
      if (!a) { a = { id: c.a.id || 'a' + Date.now().toString(36) }; alarms.push(a); }
      a.time = c.a.time; a.label = String(c.a.label || '').substr(0, 30); a.days = (c.a.days || []).filter(function (d) { return d >= 0 && d <= 6; }); a.on = c.a.on !== false; a.last = '';
      saveAlarms(); publishSoon();
    } else if (c.op === 'alarmdel' && c.id) { alarms = alarms.filter(function (y) { return y.id !== c.id; }); saveAlarms(); publishSoon(); }
    else if (c.op === 'timer' && c.sec > 0) { startTimer(Math.min(+c.sec, 24 * 3600 - 1), String(c.name || '').substr(0, 20)); }
    else if (c.op === 'timercancel') { cancelTimer(); }
    else if (c.op === 'task' && c.t && c.t.name && /^\d\d:\d\d$/.test(c.t.time)) { upsertTask(c.t); }
    else if (c.op === 'taskdel' && c.id) { delTask(c.id); }
    else if (c.op === 'rec' && c.k && c.p && c.d) { setRecord(String(c.k), String(c.p), String(c.d), !!c.on); }
    else if (c.op === 'note' && c.t) { addNote(c.id || newId(), c.t, c.c); }
    else if (c.op === 'photo' && m && m.attachment && m.attachment.url) { addPhoto(String(c.id || m.id).replace(/[^A-Za-z0-9_-]/g, ''), m.attachment.url, c.c ? decodeURIComponent(c.c) : ''); }
    else if (c.op === 'boarddel' && c.id) { delBoard(c.id); }
    else if (c.op === 'soundplay' && c.id) { playSound(c.id); }
    else if (c.op === 'soundstop') { stopSound(); }
    else if (c.op === 'sounddel' && c.id) { delSound(c.id); }
    else if (c.op === 'soundren' && c.id && c.n) { var sx = findSound(c.id); if (sx) { sx.n = String(c.n).substr(0, 60); saveSounds(); } }
    else if (c.op === 'reload') { if (HF && HF.reload) HF.reload(); return; }
    else if (c.op === 'update') { if (HF && HF.updateCheck) HF.updateCheck(); }
    else if (c.op === 'ping') { publishState(); }
    if (cur === 'alarm') { renderAlarms(); renderTimer(); }
    renderAll();
  }
  w.onNtfy = function (topic, line) {
    var m; try { m = JSON.parse(line); } catch (e) { return; }
    if (!m || !m.id || seen[m.id]) return;
    seen[m.id] = 1; Store.set('lastNtfy', m.id);
    var c; try { c = JSON.parse(m.message); } catch (e2) { return; }
    applyCommand(c, m);
  };
  function startRemote() {
    lanPush();
    if (!HF || !HF.subscribe) return;
    HF.subscribe(T_CMD, Store.get('lastNtfy', '') || '');
    publishState();
    /* الحالة تُرسل عند كل تغيير؛ وهذه نبضة كل ٣ ساعات فقط ليبقى عدد الرسائل اليومي قليلاً */
    setInterval(publishState, 3 * 3600000);
  }

  /* ---------- أوامر الاختبار ---------- */
  w.onTest = function (arg) {
    var map = { fajr: 1, dhuhr: 1, asr: 1, maghrib: 1, isha: 1 };
    if (map[arg]) { showCall(arg, 'now'); playPrayerCall(arg); }
    else if (arg === 'ramadanon') { cfg.forceRamadan = true; saveCfg(); }
    else if (arg === 'ramadanoff') { cfg.forceRamadan = false; saveCfg(); }
    else if (arg === 'eidon') { cfg.forceEid = true; saveCfg(); }
    else if (arg === 'eidoff') { cfg.forceEid = false; saveCfg(); }
    else if (arg === 'clipadhan') playPrayerCall('maghrib');
    else if (arg === 'menu') openMenu();
    else if (arg === 'alarm') ringAlarm({ label: 'تجربة المنبه' });
    else if (arg === 'remind') { var te = { title: 'تجربة التذكير', time: '10:30', kind: 'event' }; showRemind('pre', te); sayNow(evSay('pre', te)); }
    else if (arg === 'readtoday') readToday();
    else if (PAGES.indexOf(arg) >= 0) show(arg);
    renderAll();
  };

  /* ---------- التحديث عن بعد (Updater.java): صفحات جديدة تُحمَّل حين يكون الإطار هادئاً ---------- */
  var updPending = false, updStatus = '';
  function updInfo() { try { return JSON.parse(HF && HF.updateInfo ? HF.updateInfo() : '{}'); } catch (e) { return {}; } }
  w.onUpdateReady = function () { updPending = true; };
  w.onUpdateStatus = function (s) { updStatus = s; if ($('menu').className.indexOf('show') >= 0) $('m-info').textContent = menuInfo(); lanSoon(); };
  /* لا تُبدَّل الصفحات أثناء صوت أو نافذة مفتوحة أو لمس قريب، ولا قبل الصلاة بخمس دقائق */
  function tickUpdate(now) {
    if (!updPending || speaking || audioBusy() || document.querySelector('.overlay.show') || Date.now() - lastTouch < 60000) return;
    if (nextPrayer(now).at - now < 5 * 60000) return;
    updPending = false; if (HF && HF.applyUpdate) HF.applyUpdate();
  }
  function menuInfo() {
    var u = updInfo();
    return cfg.name + ' · رمز الإطار للجوال: ' + secret + (u.name ? ' · النسخة ' + u.name + ' (صفحات ' + u.web + ')' + (u.owner ? ' · تحديث صامت ✓' : '') : '') + (updStatus ? ' · ' + updStatus : '');
  }
  w.onClockFixed = function () { tcache = {}; setTimeout(function () { gcalSync(true); }, 3000); if (calAuto) calToday(); renderAll(); loadWeather(); ensureTts(); };
  function renderAll() { tickClock(); renderHomeEvents(); if (cur === 'prayers') renderPrayers(); if (cur === 'cal') renderCal(); if (cur === 'events') renderEvents(); if (cur === 'kids') renderKids(); if (cur === 'alarm') renderAlarms(); if (cur === 'tasks') renderTasks(); }

  /* ---------- الأحداث ---------- */
  function wire() {
    each(document.querySelectorAll('#nav button'), function (b) { b.onclick = function () { show(b.getAttribute('data-p')); }; });
    $('ad-m').onclick = function () { stopSpeak(); adSet = 'morning'; adIdx = 0; renderAdhkar(false); };
    $('ad-e').onclick = function () { stopSpeak(); adSet = 'evening'; adIdx = 0; renderAdhkar(false); };
    $('ad-pp').onclick = function () { if (HF && HF.audioToggle) $('ad-pp').textContent = HF.audioToggle() ? '❚❚' : '▶'; };
    $('ad-pbar').onclick = function (ev) { var r = this.getBoundingClientRect(); var pct = Math.round((r.right - ev.clientX) / r.width * 100); if (HF && HF.audioSeek) HF.audioSeek(Math.max(0, Math.min(100, pct))); };
    $('ad-next').onclick = function () { adMove(1); };
    $('ad-prev').onclick = function () { adMove(-1); };
    $('cal-next').onclick = function () { calStep(1); };
    $('cal-prev').onclick = function () { calStep(-1); };
    $('cal-grid').onclick = function (ev) {
      dayFromHome = false;
      var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-d'))) n = n.parentNode;
      if (n && n.getAttribute && n.getAttribute('data-d')) openDay(L.parseYmd(n.getAttribute('data-d')));
    };
    $('day-close').onclick = closeAll;
    $('f-add').onclick = function () {
      var title = $('f-title').value.replace(/^\s+|\s+$/g, '');
      if (!title) return;
      var when = $('f-date').value || ymd(dayDate);
      addEvent({ id: newId(), title: title, date: when, time: getTimeFields('f-th', 'f-tm', 'f-tap'), repeat: $('f-rep').value, kind: 'event' });
      if (HF && HF.hideKeyboard) HF.hideKeyboard();
      if (dayFromHome) { closeAll(); renderAll(); return; }
      openDay(dayDate); renderAll();
    };
    /* اختصار الاستسقاء: يكتب العنوان فيظهر الموعد في صفحة الصلاة (الكسوف والخسوف تلقائيان) */
    $('f-quick').onclick = function (ev) { var t = ev.target.getAttribute('data-t'); if (t) { $('f-title').value = t; if (!getTimeFields('f-th', 'f-tm', 'f-tap')) setTimeFields('f-th', 'f-tm', 'f-tap', '06:30'); } };
    $('home-add').onclick = function () { dayFromHome = true; openDay(new Date()); };
    $('ev-add').onclick = function () { dayFromHome = true; openDay(new Date()); };
    /* أيام الميلاد: نموذج خاص منفصل عن المواعيد */
    $('bd-add').onclick = function () { openBdForm(null); };
    $('day-bd').onclick = function () { var d = dayDate; closeAll(); openBdForm(d); };
    $('bd-close').onclick = closeAll;
    $('bd-save').onclick = saveBdForm;
    $('bd-emo').onclick = function (ev) { var e = ev.target.getAttribute('data-e'); if (e) { bdEmo = e; renderEmo(); } };
    $('bd-list').onclick = $('bd-hero').onclick = function (ev) { var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-id'))) n = n.parentNode; if (n && n !== this) openBdInfo(n.getAttribute('data-id')); };
    $('bi-close').onclick = closeAll;
    $('bi-del').onclick = function () {
      if (this.className.indexOf('sure') < 0) { this.className = 'btn danger sure'; this.textContent = 'تأكيد الحذف'; return; }
      delEvent(bdInfoId); closeAll(); renderAll(); if (cur === 'bdays') renderBdays(); toast('تم الحذف');
    };
    /* المؤقت وساعة الإيقاف */
    $('al-seg').onclick = function (ev) { var s = ev.target.getAttribute('data-s'); if (s) setSeg(s); };
    $('tm-names').onclick = function (ev) { var n = ev.target.getAttribute('data-n'); if (n !== null) { tmName = n; renderTmChips(); } };
    $('tm-pre').onclick = function (ev) { var s = +ev.target.getAttribute('data-sec'); if (s) startTimer(s, tmName); };
    $('tm-start').onclick = function () { var s = tmSet.h * 3600 + tmSet.m * 60 + tmSet.s; if (!s) { toast('اختر مدة المؤقت أولاً'); return; } startTimer(s, tmName); };
    $('tm-pause').onclick = pauseTimer;
    $('tm-plus').onclick = plusMinute;
    $('tm-cancel').onclick = cancelTimer;
    $('td-stop').onclick = closeAll;
    $('sw-a').onclick = swMain;
    $('sw-b').onclick = swSide;
    $('tpill').onclick = function (ev) { var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-go'))) n = n.parentNode; show('alarm'); setSeg(n && n.getAttribute && n.getAttribute('data-go') || (tm ? 'timer' : 'sw')); };
    /* الضغط المطوّل على + أو − يكرر الخطوة */
    var rep = null, repT = null;
    function stepStart(ev) {
      var b = ev.target; if (!b.getAttribute || !b.getAttribute('data-k')) return;
      var k = b.getAttribute('data-k'), d = +b.getAttribute('data-d');
      stepTimer(k, d); clearTimeout(repT); clearInterval(rep);
      repT = setTimeout(function () { rep = setInterval(function () { stepTimer(k, d); }, 90); }, 450);
    }
    function stepEnd() { clearTimeout(repT); clearInterval(rep); }
    $('tm-pick').addEventListener('touchstart', stepStart);
    $('tm-pick').addEventListener('touchend', stepEnd);
    $('tm-pick').addEventListener('touchcancel', stepEnd);
    $('tm-pick').addEventListener('mousedown', function (ev) { if (!('ontouchstart' in w)) stepStart(ev); });
    $('tm-pick').addEventListener('mouseup', stepEnd);
    /* لوحة العائلة */
    $('bo-list').onclick = function (ev) {
      var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-pv'))) n = n.parentNode;
      if (!n || n === this) return;
      openViewer(n.getAttribute('data-pv'));
    };
    $('pv-close').onclick = closeAll;
    $('pv-next').onclick = function () { pvMove(1); };
    $('pv-prev').onclick = function () { pvMove(-1); };
    /* السحب في العارض: لليسار = التالي ولليمين = السابق (مثل السحب بين صفحات الإطار) */
    var pvx = 0, pvy = 0;
    $('photoview').addEventListener('touchstart', function (e) { pvx = e.touches[0].clientX; pvy = e.touches[0].clientY; });
    $('photoview').addEventListener('touchend', function (e) {
      var t = e.changedTouches[0], dx = t.clientX - pvx, dy = t.clientY - pvy;
      if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy)) pvMove(dx < 0 ? 1 : -1);
    });
    $('m-board').onclick = function () { closeAll(); openBoardEdit(); };
    /* المهام اليومية */
    $('m-tasks').onclick = function () { closeAll(); openTaskEdit(true); };
    $('tk-add').onclick = function () { openTaskEdit(false); };
    $('tc-ok').onclick = closeAll;
    $('te-close').onclick = closeAll;
    $('te-names').onclick = function (ev) { var n = ev.target.getAttribute('data-n'); if (n) $('te-name').value = n; };
    $('te-days').onclick = function (ev) { if (ev.target.getAttribute('data-d') !== null) ev.target.className = ev.target.className === 'on' ? '' : 'on'; };
    $('te-kids').onclick = function (ev) {
      var k = ev.target.getAttribute('data-k'); if (!k) return;
      var i = tkKids.indexOf(k); if (i >= 0) tkKids.splice(i, 1); else tkKids.push(k); renderTkKids();
    };
    $('te-add').onclick = function () {
      var name = $('te-name').value.replace(/^\s+|\s+$/g, ''); if (!name) { toast('اختر اسم المهمة أو اكتبه'); return; }
      var t = getTimeFields('te-th', 'te-tm', 'te-tap');
      var days = []; each(document.querySelectorAll('#te-days button.on'), function (b) { days.push(+b.getAttribute('data-d')); });
      var nt = upsertTask({ id: newId(), name: name, time: t, days: days, kids: tkKids.slice(), dur: +$('te-dh').value * 60 + +$('te-dm').value });
      if (HF && HF.hideKeyboard) HF.hideKeyboard();
      $('te-name').value = ''; renderTaskManage(); renderAll(); toast('أُضيفت المهمة: ' + name + (nt.from > ymd(new Date()) ? ' — تبدأ من الغد لأن وقتها فات اليوم' : ''));
      if (!teFull) closeAll();
    };
    $('te-list').onclick = function (ev) {
      var n = ev.target; while (n && n !== this && !(n.getAttribute && (n.getAttribute('data-tog') || n.getAttribute('data-id')))) n = n.parentNode;
      if (!n || n === this) return;
      var tog = n.getAttribute('data-tog');
      if (tog) { each(tasks, function (t) { if (t.id === tog) t.on = t.on === false; }); saveTasks(); renderTaskManage(); return; }
      if (n.className.indexOf('sure') < 0) { n.className = 'del sure'; n.textContent = 'تأكيد الحذف'; return; }
      delTask(n.getAttribute('data-id')); renderTaskManage(); toast('حُذفت المهمة');
    };
    $('bo-colors').onclick = function (ev) { var c = ev.target.getAttribute('data-c'); if (c === null) return; boColor = +c; each(this.querySelectorAll('button'), function (b) { b.className = 'nc' + b.getAttribute('data-c') + (b === ev.target ? ' on' : ''); }); };
    $('bo-add').onclick = function () { var t = $('bo-text').value; if (!t.replace(/\s/g, '')) return; addNote(newId(), t, boColor); $('bo-text').value = ''; if (HF && HF.hideKeyboard) HF.hideKeyboard(); renderBoardManage(); toast('أضيفت للوحة العائلة'); };
    $('bo-close').onclick = closeAll;
    $('bo-manage').onclick = function (ev) {
      var b = ev.target, id = b.getAttribute && b.getAttribute('data-id'); if (!id) return;
      if (b.className.indexOf('sure') < 0) { b.className = 'del sure'; b.textContent = 'تأكيد الحذف'; return; }
      delBoard(id); renderBoardManage(); toast('تم الحذف');
    };
    $('home-say').onclick = readToday;
    $('rm-ok').onclick = closeAll;
    $('m-kids').onclick = function () { closeAll(); openKidsEdit(); };
    $('ke-add').onclick = function () {
      if ($('ke-list').querySelectorAll('.kerow').length >= 6) return;
      var d = document.createElement('div');
      d.innerHTML = keRow('k' + Date.now().toString(36), '');
      $('ke-list').appendChild(d.firstChild);
    };
    $('ke-list').onclick = function (ev) {
      if (ev.target.className !== 'del') return;
      var rows = $('ke-list').querySelectorAll('.kerow');
      if (rows.length > 1) ev.target.parentNode.parentNode.removeChild(ev.target.parentNode);
    };
    $('ke-save').onclick = saveKidsEdit;
    $('ke-close').onclick = closeAll;
    $('day-list').onclick = function (ev) { var id = ev.target.getAttribute('data-id'); if (id) { delEvent(id); openDay(dayDate); renderAll(); } };
    $('kids-wrap').onclick = function (ev) { var r = ev.target.getAttribute && ev.target.getAttribute('data-rep'); if (r) openReport(r, false); };
    /* صفحة المهام: صح على ما حلّ وقته فقط (وإزالته إن ضُغط خطأً) */
    $('tk-list').onclick = function (ev) {
      var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-p'))) n = n.parentNode;
      if (!n || n === this) return;
      if (n.className.indexOf('soon') >= 0) { toast('لم يحن وقت «' + n.getElementsByTagName('b')[0].textContent + '» بعد'); return; }
      toggleRecord(n.getAttribute('data-k'), n.getAttribute('data-p'), ymd(new Date()));
    };
    /* التقرير: عرض للجميع، والتعديل من القائمة المخفية فقط */
    $('rep-kids').onclick = function (ev) { var k = ev.target.getAttribute('data-rk'); if (k) { repKid = k; renderReport(); } };
    $('rep-prev').onclick = function () { repEnd = dayOff(repEnd, -7); renderReport(); };
    $('rep-next').onclick = function () { var t = new Date(); repEnd = dayOff(repEnd, 7); if (repEnd > t) repEnd = t; renderReport(); };
    $('rep-body').onclick = function (ev) {
      if (!repEdit) return;
      var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-d'))) n = n.parentNode;
      if (!n || n === this) return;
      setRecord(repKid, n.getAttribute('data-p'), n.getAttribute('data-d'), n.className.indexOf('s3') < 0); renderReport();
    };
    $('m-report').onclick = function () { closeAll(); openReport(null, true); };
    $('m-adh').onclick = function () { closeAll(); openAdhEdit(); };
    $('ah-mw').onchange = $('ah-mt').onchange = function () { adhSelChanged('m'); };
    $('ah-ew').onchange = $('ah-et').onchange = function () { adhSelChanged('e'); };
    $('ah-save').onclick = saveAdhEdit;
    $('ah-close').onclick = closeAll;
    $('call-kids').onclick = function (ev) {
      var k = ev.target.getAttribute('data-k'); if (!k) return;
      toggleRecord(k, ev.target.getAttribute('data-p'), ymd(new Date()));
      showCall(ev.target.getAttribute('data-p'), 'now', callKey);
    };
    $('call-close').onclick = hideCall;
    $('ad-card').onclick = function (ev) { var n = ev.target; while (n && n !== this && n.id !== 'ad-spk') n = n.parentNode; if (n && n.id === 'ad-spk') speakAdhkar(); };
    $('al-add').onclick = function () { openAlarmEdit(null); };
    $('al-list').onclick = function (ev) {
      var n = ev.target, id = null, tog = false;
      while (n && n !== this) { if (n.getAttribute && n.getAttribute('data-tog')) { id = n.getAttribute('data-tog'); tog = true; break; } if (n.getAttribute && n.getAttribute('data-id')) { id = n.getAttribute('data-id'); break; } n = n.parentNode; }
      if (!id) return;
      if (tog) { each(alarms, function (a) { if (a.id === id) { a.on = !a.on; a.last = ''; } }); saveAlarms(); renderAlarms(); } else openAlarmEdit(id);
    };
    $('al-days').onclick = function (ev) { if (ev.target.getAttribute('data-d') !== null) ev.target.className = ev.target.className === 'on' ? '' : 'on'; };
    $('al-save').onclick = saveAlarmEdit;
    $('al-close').onclick = closeAll;
    $('al-del').onclick = function () { alarms = alarms.filter(function (a) { return a.id !== alEditId; }); saveAlarms(); closeAll(); renderAlarms(); };
    $('ar-stop').onclick = stopAlarm;
    $('ar-snooze').onclick = snoozeAlarm;
    $('m-alarm').onclick = function () { closeAll(); show('alarm'); };
    $('m-city').onclick = function () { closeAll(); openCity(); };
    $('m-events').onclick = function () { closeAll(); openEvManage(); };
    $('em-close').onclick = closeAll;
    $('em-list').onclick = function (ev) {
      var b = ev.target, id = b.getAttribute && b.getAttribute('data-id');
      if (!id) return;
      if (b.className.indexOf('sure') < 0) { b.className = 'del sure'; b.textContent = 'تأكيد الحذف'; return; }
      delEvent(id); renderAll(); openEvManage(); toast('تم الحذف');
    };
    $('ct-close').onclick = closeAll;
    $('ct-list').onclick = function (ev) { var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-i') !== null)) n = n.parentNode; if (n && n !== this) pickCity(+n.getAttribute('data-i')); };
    $('rep-close').onclick = function () { $('report').className = 'overlay'; };
    $('m-close').onclick = closeAll;
    $('snd-stop').onclick = stopSound;
    $('m-settings').onclick = pressSettings;
    $('sc-open').onclick = confirmSettings;
    $('sc-cancel').onclick = function () { $('setconfirm').className = 'overlay'; };
    $('m-wifi').onclick = function () { closeAll(); openWifi(); };
    $('wf-refresh').onclick = function () { $('wf-pass').style.display = 'none'; $('wf-list').style.display = ''; wfCurrent(); wfScan(); };
    $('wf-close').onclick = closeAll;
    $('wf-cancel').onclick = function () { $('wf-pass').style.display = 'none'; $('wf-list').style.display = ''; };
    $('wf-list').onclick = function (ev) {
      var n = ev.target; while (n && n !== this && !(n.getAttribute && n.getAttribute('data-s'))) n = n.parentNode;
      if (!n || n === this) return;
      wfSel = n.getAttribute('data-s');
      if (n.getAttribute('data-k') === '1') { $('wf-sel').textContent = 'كلمة مرور: ' + wfSel; $('wf-pw').value = ''; $('wf-pass').style.display = ''; $('wf-list').style.display = 'none'; }
      else { wfConnect(wfSel, ''); }
    };
    $('wf-go').onclick = function () { var s = wfSel, p = $('wf-pw').value; if (!s) return; if (HF && HF.hideKeyboard) HF.hideKeyboard(); $('wf-pass').style.display = 'none'; $('wf-list').style.display = ''; wfConnect(s, p); };
    $('m-reload').onclick = function () { if (HF) HF.reload(); else location.reload(); };
    $('m-upd').onclick = function () { if (HF && HF.updateCheck) { HF.updateCheck(); toast('جارٍ البحث عن تحديث…'); } };
    $('m-adhan').onclick = function () { playPrayerCall(nextPrayer(new Date()).name); };
    $('m-ram').onclick = function () { cfg.forceRamadan = !cfg.forceRamadan; saveCfg(); openMenu(); renderAll(); publishSoon(); };
    $('m-eid').onclick = function () { cfg.forceEid = !cfg.forceEid; saveCfg(); openMenu(); renderAll(); publishSoon(); };
    $('m-rot').onclick = function () { cfg.rotate = !cfg.rotate; saveCfg(); openMenu(); };
    $('m-vol').oninput = function () { if (HF && HF.setVolume) HF.setVolume(parseInt(this.value, 10)); };

    /* لمس: إيقاف التدوير + السحب للتنقل + ضغطة مطوّلة على الساعة تفتح القائمة.
       القائمة تُفتح عند رفع الإصبع ويُلغى «النقر» التابع له، فلا يقع على زر تحت الإصبع */
    var sx = 0, sy = 0, lp = null, taps = [], menuOnEnd = false, lpFired = false;
    document.addEventListener('touchstart', function (e) {
      lastTouch = Date.now(); var t = e.touches[0]; sx = t.clientX; sy = t.clientY;
      clearTimeout(lp); lpFired = false;
      var n = e.target; while (n && n.id !== 'clockbox') n = n.parentNode;
      if (n) {
        lp = setTimeout(function () { lpFired = true; openMenu(); }, 1500);
        /* القائمة المخفية: 5 لمسات سريعة على الساعة */
        var nowMs = Date.now();
        taps = taps.filter(function (t) { return nowMs - t < 3500; });
        taps.push(nowMs);
        if (taps.length >= 5) { taps = []; clearTimeout(lp); menuOnEnd = true; }
      }
    }, true);
    document.addEventListener('touchmove', function () { clearTimeout(lp); }, true);
    document.addEventListener('touchend', function (e) {
      clearTimeout(lp);
      if (menuOnEnd || lpFired) { e.preventDefault(); if (menuOnEnd) { menuOnEnd = false; openMenu(); } lpFired = false; return; }
      var t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      if (Math.abs(dx) > 120 && Math.abs(dy) < 70 && !document.querySelector('.overlay.show')) {
        var list = navPages(), i = list.indexOf(cur);
        show(list[(i + (dx < 0 ? 1 : -1) + list.length) % list.length]);
      }
    }, true);
    document.addEventListener('mousedown', function () { lastTouch = Date.now(); }, true);
    document.addEventListener('keydown', function (e) { if (e.keyCode === 77 && e.ctrlKey) w.onMenuKey(); });
  }

  /* ---------- التشغيل ---------- */
  fillTimeSelects('f-th', 'f-tm', true);
  fillTimeSelects('al-th', 'al-tm', false);
  fillBdSelects();
  fillTimeSelects('te-th', 'te-tm', false);
  fillTimeSelects('ah-mh', 'ah-mm', false);
  fillTimeSelects('ah-eh', 'ah-em', false);
  (function () { var i, o; for (i = 0; i < 24; i++) { o = document.createElement('option'); o.value = i; o.textContent = i ? countAr(i, 'ساعة', 'ساعتين', 'ساعات', 'ساعة') : 'بدون ساعات'; $('te-dh').appendChild(o); } for (i = 0; i < 60; i++) { o = document.createElement('option'); o.value = i; o.textContent = i ? countAr(i, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة') : 'بدون دقائق'; $('te-dm').appendChild(o); } })();
  renderTmChips();
  wire();
  setSeg('alarm');
  applyTabs();
  show('home');
  /* ساعة الإيقاف تُحدَّث بأجزاء الثانية فقط وهي ظاهرة */
  setInterval(function () { if (sw.start && cur === 'alarm' && alSeg === 'sw') $('sw-time').textContent = fmtDur(swElapsed(), true); }, 100);
  tickClock();
  setInterval(tickClock, 1000);
  setInterval(function () {
    if (cur === 'prayers') renderPrayers();
    if (cur === 'home') renderHomeEvents();
    if (cur === 'tasks') renderTasks();
    if (cur === 'kids') renderKids();
    /* بعد منتصف الليل: يتحرك تحديد اليوم (والشهر إن تغيّر) */
    if (cur === 'cal' && calDay !== ymd(new Date())) { if (calAuto) calToday(); renderCal(); }
  }, 30000);
  setInterval(function () {
    if (cur === 'adhkar' && !speaking && Date.now() - lastTouch > 20000) adMove(1);
  }, 25000);
  setInterval(function () {
    if (!cfg.rotate || speaking || Date.now() - lastTouch < 60000 || document.querySelector('.overlay.show')) return;
    var list = rotationList(), i = list.indexOf(cur);
    show(list[(i + 1) % list.length]);
  }, 30000);
  loadWeather();
  setInterval(loadWeather, 15 * 60000);
  startRemote();
  /* تقرير الأبناء في صفحة الجوال يتغيّر مع دخول أوقات الصلوات والمهام */
  setInterval(lanPush, 60000);
  ensureTts();
  setTimeout(function () { gcalSync(false); }, 5000);
  setInterval(function () { gcalSync(false); }, 5 * 60000);
  setTimeout(preloadAdhkar, 30000);
})(window);
