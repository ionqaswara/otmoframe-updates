/* Clock correction. The frame has no clock battery: after a reboot the system date is 1970 until synced.
   The native side learns the real time from the internet and reports the difference; every Date in the
   page then uses the corrected time. Must load before every other script. */
(function (w) {
  var R = w.Date, off = 0;
  function D(a, b, c, d, e, f, g) {
    if (!(this instanceof D)) return new R(R.now() + off).toString();
    switch (arguments.length) {
      case 0: return new R(R.now() + off);
      case 1: return new R(a);
      default: return new R(a, b, c === undefined ? 1 : c, d || 0, e || 0, f || 0, g || 0);
    }
  }
  D.prototype = R.prototype;
  D.now = function () { return R.now() + off; };
  D.UTC = R.UTC;
  D.parse = R.parse;
  w.Date = D;

  /* true once the shown time can be trusted */
  w.clockOk = function () { return new D().getFullYear() >= 2025; };
  function poll() {
    try {
      var o = w.HomeFrame && w.HomeFrame.timeOffset ? w.HomeFrame.timeOffset() : '0';
      if (o !== 'x') {
        var n = +o;
        if (Math.abs(n - off) > 2000) { off = n; if (w.onClockFixed) w.onClockFixed(); }
      }
    } catch (e) { }
  }
  poll();
  setInterval(poll, 10000);
})(window);
