/* قراءة تقويم iCal (الرابط السري لتقويم قوقل) وتحويله لمواعيد الإطار. ES5 لـ WebView أندرويد ٦.
   يدعم: أحداث اليوم الكامل والموقّتة (محلي أو UTC)، الأحداث متعددة الأيام، التكرار RRULE
   (DAILY/WEEKLY/MONTHLY/YEARLY مع INTERVAL وCOUNT وUNTIL وBYDAY وBYMONTHDAY وBYMONTH)، EXDATE، والتعديلات RECURRENCE-ID.
   المنطقة الزمنية TZID تُعامل كوقت الجهاز (مكة/الرياض)، وأوقات UTC (Z) تُحوَّل للوقت المحلي. */
(function (w) {
  var DAY = 86400000, WD = { SU: 0, MO: 1, TU: 2, WE: 3, TH: 4, FR: 5, SA: 6 };
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function unesc(v) { return v.replace(/\\[nN]/g, ' ').replace(/\\([,;\\])/g, '$1').replace(/^\s+|\s+$/g, ''); }

  /* "20261025" أو "20261025T103000" أو "20261025T073000Z" → {d: تاريخ محلي (منتصف الليل)، t: "HH:MM" أو ""} */
  function parseDT(v) {
    var m = /^(\d{4})(\d\d)(\d\d)(?:T(\d\d)(\d\d)(\d\d)?(Z)?)?/.exec(v || '');
    if (!m) return null;
    if (!m[4]) return { d: new Date(+m[1], +m[2] - 1, +m[3]), t: '' };
    var x = m[7] ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0))) : new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
    return { d: new Date(x.getFullYear(), x.getMonth(), x.getDate()), t: pad(x.getHours()) + ':' + pad(x.getMinutes()) };
  }

  /* النص → قائمة أحداث خام {uid, sum, st, en, rrule, ex{}, rid, cancel} */
  function parse(text) {
    var lines = String(text || '').replace(/\r?\n[ \t]/g, '').split(/\r?\n/), out = [], ev = null, depth = 0, i;
    for (i = 0; i < lines.length; i++) {
      var ln = lines[i]; if (!ln) continue;
      var c = ln.indexOf(':'); if (c < 0) continue;
      var head = ln.substr(0, c), val = ln.substr(c + 1), name = head.split(';')[0].toUpperCase();
      if (name === 'BEGIN') { if (val === 'VEVENT') { ev = { ex: {} }; depth = 0; } else if (ev) depth++; continue; }
      if (name === 'END') { if (val === 'VEVENT' && ev) { out.push(ev); ev = null; } else if (ev) depth--; continue; }
      if (!ev || depth > 0) continue; /* تجاهل ما داخل VALARM */
      if (name === 'UID') ev.uid = val;
      else if (name === 'SUMMARY') ev.sum = unesc(val);
      else if (name === 'DTSTART') ev.st = parseDT(val);
      else if (name === 'DTEND') ev.en = parseDT(val);
      else if (name === 'RRULE') ev.rrule = val;
      else if (name === 'EXDATE') { var xs = val.split(','); for (var k = 0; k < xs.length; k++) { var x = parseDT(xs[k]); if (x) ev.ex[ymd(x.d)] = 1; } }
      else if (name === 'RECURRENCE-ID') { var r = parseDT(val); if (r) ev.rid = ymd(r.d); }
      else if (name === 'STATUS') ev.cancel = val.toUpperCase() === 'CANCELLED';
    }
    return out;
  }

  function rule(s) {
    var o = {}, p = String(s).split(';'), i;
    for (i = 0; i < p.length; i++) { var kv = p[i].split('='); if (kv.length === 2) o[kv[0].toUpperCase()] = kv[1]; }
    var r = { f: o.FREQ, iv: Math.max(1, +o.INTERVAL || 1), count: +o.COUNT || 0, until: o.UNTIL ? parseDT(o.UNTIL).d : null, byday: [], bymd: [], bymon: [] };
    if (o.BYDAY) each(o.BYDAY.split(','), function (x) { var m = /^([+-]?\d+)?(SU|MO|TU|WE|TH|FR|SA)$/.exec(x); if (m) r.byday.push({ n: m[1] ? +m[1] : 0, wd: WD[m[2]] }); });
    if (o.BYMONTHDAY) each(o.BYMONTHDAY.split(','), function (x) { r.bymd.push(+x); });
    if (o.BYMONTH) each(o.BYMONTH.split(','), function (x) { r.bymon.push(+x - 1); });
    return r;
  }
  function each(a, f) { for (var i = 0; i < a.length; i++) f(a[i], i); }
  function dayNo(d) { return Math.round((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())) / DAY); }
  function dim(d) { return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); }
  /* هل اليوم d يطابق «nth weekday» في شهره (2MO = ثاني اثنين، -1FR = آخر جمعة) */
  function nthOk(d, b) {
    if (d.getDay() !== b.wd) return false;
    if (!b.n) return true;
    if (b.n > 0) return Math.ceil(d.getDate() / 7) === b.n;
    return Math.ceil((dim(d) - d.getDate() + 1) / 7) === -b.n;
  }
  function mdOk(d, list) { for (var i = 0; i < list.length; i++) { var v = list[i]; if (v > 0 ? d.getDate() === v : d.getDate() === dim(d) + v + 1) return true; } return false; }
  function bdOk(d, list) { for (var i = 0; i < list.length; i++) if (nthOk(d, list[i])) return true; return false; }

  function matches(r, st, d) {
    var dd = dayNo(d) - dayNo(st);
    if (dd < 0) return false;
    if (r.f === 'DAILY') return dd % r.iv === 0 && (!r.byday.length || bdOk(d, r.byday)) && (!r.bymon.length || r.bymon.indexOf(d.getMonth()) >= 0);
    if (r.f === 'WEEKLY') {
      var mon0 = dayNo(st) - ((st.getDay() + 6) % 7), wk = Math.floor((dayNo(d) - mon0) / 7);
      if (wk % r.iv) return false;
      return r.byday.length ? bdOk(d, r.byday) : d.getDay() === st.getDay();
    }
    var months = (d.getFullYear() - st.getFullYear()) * 12 + d.getMonth() - st.getMonth();
    if (r.f === 'MONTHLY') {
      if (months % r.iv) return false;
      if (r.bymd.length) return mdOk(d, r.bymd);
      if (r.byday.length) return bdOk(d, r.byday);
      return d.getDate() === st.getDate();
    }
    if (r.f === 'YEARLY') {
      if ((d.getFullYear() - st.getFullYear()) % r.iv) return false;
      if (r.bymon.length ? r.bymon.indexOf(d.getMonth()) < 0 : d.getMonth() !== st.getMonth()) return false;
      if (r.bymd.length) return mdOk(d, r.bymd);
      if (r.byday.length) return bdOk(d, r.byday);
      return d.getDate() === st.getDate();
    }
    return false;
  }

  /* يوم الميلاد: عنوان يبدأ بـ 🎂 أو «ميلاد …» / «عيد ميلاد …» → الاسم وحده */
  function bdName(t) {
    var m = /^\s*(?:🎂\s*)?(?:عيد\s+)?ميلاد\s+(.+)$/.exec(t) || /^\s*🎂\s*(.+)$/.exec(t);
    return m ? m[1].replace(/^\s+|\s+$/g, '') : null;
  }

  /* أحداث الإطار من النص بين from و to (تاريخان): مواعيد فردية لكل ظهور، وأيام الميلاد سنوية بلا سنة */
  function expand(text, from, to) {
    var raw = parse(text), over = {}, out = [], bds = {}, i;
    each(raw, function (e) { if (e.rid && e.uid) over[e.uid + '|' + e.rid] = 1; });
    var f0 = dayNo(from), t0 = dayNo(to);
    function push(e, d) {
      if (out.length > 3000) return;
      var title = e.sum || 'موعد', bn = bdName(title);
      if (bn) {
        var key = bn + '|' + pad(d.getMonth() + 1) + pad(d.getDate());
        if (!bds[key]) { bds[key] = 1; out.push({ id: 'g' + key.replace(/[^A-Za-z0-9]/g, '') + Math.abs(hash(key)), title: bn, date: '1900-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()), time: '', repeat: 'yearly', kind: 'birthday', src: 'g' }); }
        return;
      }
      var n = dayNo(d); if (n < f0 || n > t0) return;
      out.push({ id: 'g' + Math.abs(hash((e.uid || title) + ymd(d))), title: title.substr(0, 80), date: ymd(d), time: e.st.t, repeat: 'none', kind: 'event', src: 'g' });
    }
    each(raw, function (e) {
      if (!e.st || e.cancel) return;
      /* الأحداث متعددة الأيام (اليوم الكامل): تظهر في كل يوم حتى ١٤ يوماً */
      var span = 1;
      if (!e.st.t && e.en && !e.en.t) span = Math.max(1, Math.min(14, dayNo(e.en.d) - dayNo(e.st.d)));
      function occ(d) { for (var k = 0; k < span; k++) push(e, new Date(d.getFullYear(), d.getMonth(), d.getDate() + k)); }
      if (!e.rrule || e.rid) { occ(e.st.d); return; }
      var r = rule(e.rrule); if (!r.f) { occ(e.st.d); return; }
      /* أيام الميلاد السنوية: ظهور واحد يكفي */
      if (bdName(e.sum || '') && r.f === 'YEARLY') { push(e, e.st.d); return; }
      var start = dayNo(e.st.d), begin = r.count ? start : Math.max(start, f0 - span), end = Math.min(t0, start + 366 * 30), cnt = 0, d;
      if (r.until) end = Math.min(end, dayNo(r.until));
      for (var n = begin; n <= end; n++) {
        d = new Date(e.st.d.getFullYear(), e.st.d.getMonth(), e.st.d.getDate() + (n - start));
        if (!matches(r, e.st.d, d)) continue;
        cnt++;
        if (r.count && cnt > r.count) break;
        var key = ymd(d);
        if (e.ex[key] || over[e.uid + '|' + key]) continue;
        occ(d);
      }
    });
    return out;
  }
  function hash(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return h; }

  w.ICal = { parse: parse, expand: expand, bdName: bdName };
})(typeof window !== 'undefined' ? window : this);
